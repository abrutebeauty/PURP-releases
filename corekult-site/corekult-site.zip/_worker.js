// COREKULT backend (Cloudflare Pages advanced mode).
// Needs in Cloudflare Pages > corekult > Settings:
//   KV binding  CK         -> KV namespace "corekult"   (pack data, uploads, sales)
//   Secret      ADMIN_KEY  -> Eman's admin key (Eman types it, nobody else)
//   Secret      PAYHIP_KEY -> optional, Payhip API key, to check webhook signatures
// Without CK the shop falls back to the static products.json and admin is read-only.

const JSON_H = { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" };
const json = (d, s = 200, h = {}) => new Response(JSON.stringify(d), { status: s, headers: { ...JSON_H, ...h } });
const enc = new TextEncoder();

async function hmac(key, msg) {
  const k = await crypto.subtle.importKey("raw", enc.encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", k, enc.encode(msg));
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function sha256(s) {
  const d = await crypto.subtle.digest("SHA-256", enc.encode(s));
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function cookie(req, name) {
  const m = (req.headers.get("cookie") || "").match(new RegExp("(?:^|;\\s*)" + name + "=([^;]+)"));
  return m ? m[1] : null;
}
// session cookie = "<expiry>.<hmac(ADMIN_KEY, expiry)>"
async function isAdmin(req, env) {
  if (!env.ADMIN_KEY) return false;
  const c = cookie(req, "ck_admin");
  if (!c) return false;
  const [exp, sig] = c.split(".");
  if (!exp || !sig || +exp < Date.now()) return false;
  return sig === (await hmac(env.ADMIN_KEY, exp));
}

/* EUR for Europe, USD for everyone else (the Nordics too, Eman's call) */
const EURO = new Set("AT BE BG HR CY CZ EE FR DE GR HU IE IT LV LT LU MT NL PL PT RO SK SI ES GB CH LI AD MC SM VA AL BA ME MK RS XK MD UA GI IM JE GG FO".split(" "));
const payCurrency = (c) => (EURO.has(String(c).toUpperCase()) ? "EUR" : "USD");
const FX_FALLBACK = { EUR: 1, USD: 1.08, GBP: 0.85, SEK: 11.4, NOK: 11.7, DKK: 7.46, CHF: 0.95, PLN: 4.3, CZK: 25.2, HUF: 395, RON: 4.97, BGN: 1.96, ISK: 150, TRY: 37, CAD: 1.5, AUD: 1.65, NZD: 1.8, JPY: 165, KRW: 1480, CNY: 7.8, HKD: 8.4, SGD: 1.45, INR: 91, IDR: 17300, MYR: 4.9, PHP: 62, THB: 37, BRL: 6.2, MXN: 20, ZAR: 19.5, ILS: 4 };
async function fxRates() {
  const cache = caches.default, key = new Request("https://corekult.com/__fx");
  const hit = await cache.match(key); if (hit) return hit.json();
  let rates = FX_FALLBACK;
  try {
    const r = await fetch("https://api.frankfurter.app/latest?from=EUR", { cf: { cacheTtl: 21600 } });
    if (r.ok) { const d = await r.json(); if (d && d.rates) rates = { EUR: 1, ...d.rates }; }
  } catch (e) {}
  await cache.put(key, new Response(JSON.stringify(rates), { headers: { "content-type": "application/json", "cache-control": "max-age=21600" } }));
  return rates;
}
/* ---------- stats (D1 "DB"): anonymous events, visitor id only after cookie OK ---------- */
let dbReady = false;
async function db(env) {
  if (!env.DB) return null;
  if (!dbReady) {
    await env.DB.batch([
      env.DB.prepare("CREATE TABLE IF NOT EXISTS ev (ts INTEGER, day TEXT, t TEXT, pack TEXT, x TEXT, ref TEXT, vid TEXT, sid TEXT, country TEXT, dev TEXT, val REAL)"),
      env.DB.prepare("CREATE INDEX IF NOT EXISTS ev_day ON ev(day)"),
      env.DB.prepare("CREATE INDEX IF NOT EXISTS ev_ref ON ev(ref)"),
    ]);
    dbReady = true;
  }
  return env.DB;
}
const EV_TYPES = new Set(["view", "pack", "play", "cart", "checkout", "buy", "free", "claim", "consent"]);
const clip = (v, n) => (v == null ? null : String(v).slice(0, n));
async function settings(env) { return (env.CK && (await env.CK.get("settings", "json"))) || {}; }
async function fileDeals(env, req) {
  try { return (await (await env.ASSETS.fetch(new Request(new URL("/products.json", req.url)))).json()).deals || null; } catch (e) { return null; }
}
async function loadPacks(env, req) {
  if (env.CK) {
    const d = await env.CK.get("packs", "json");
    if (d) {   // saved edits win; previews added to products.json later still show up (with their waveforms)
      try {
        const f = await (await env.ASSETS.fetch(new Request(new URL("/products.json", req.url)))).json();
        const fb = Object.fromEntries(f.products.map((p) => [p.id, p]));
        d.products.forEach((p) => {
          const q = fb[p.id]; if (!q) return;
          const qs = Object.fromEntries((q.sounds || []).map((s) => [s.file, s]));
          p.sounds = p.sounds || [];
          p.sounds.forEach((s) => { if (!s.w && qs[s.file] && qs[s.file].w) s.w = qs[s.file].w; });
          const have = new Set(p.sounds.map((s) => s.file));
          (q.sounds || []).forEach((s) => { if (!have.has(s.file)) p.sounds.push(s); });
        });
      } catch (e) {}
      return d;
    }
  }
  const r = await env.ASSETS.fetch(new Request(new URL("/products.json", req.url)));
  const d = await r.json();
  d.products.forEach((p) => { p.status = p.status || "live"; });
  return d;
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const p = url.pathname;

    // ---------- public ----------
    if (p === "/api/products") {
      const d = await loadPacks(env, req);
      const products = d.products.filter((x) => (x.status || "live") === "live")
        .map(({ notes, reviewUrl, status, ...x }) => ({ ...x, sounds: (x.sounds || []).filter((s) => !s.hidden) }));
      const country = (req.cf && req.cf.country) || req.headers.get("cf-ipcountry") || "";
      const st = await settings(env);
      return json({ currency: d.currency, pay: payCurrency(country), country, worlds: d.worlds, products, deals: d.deals || (await fileDeals(env, req)), clarity: st.clarityId || "" });
    }
    if (p.startsWith("/f/")) {                       // uploaded covers / previews
      if (!env.CK) return new Response("not found", { status: 404 });
      const o = await env.CK.getWithMetadata("file:" + decodeURIComponent(p.slice(3)), "arrayBuffer");
      if (!o.value) return new Response("not found", { status: 404 });
      return new Response(o.value, { headers: { "content-type": (o.metadata && o.metadata.type) || "application/octet-stream", "cache-control": "public, max-age=31536000, immutable" } });
    }
    if (p === "/api/payhip" && req.method === "POST") {   // Payhip webhook: paid / refunded
      if (!env.CK) return json({ ok: false }, 503);
      const b = await req.json().catch(() => null);
      if (!b) return json({ ok: false }, 400);
      if (env.PAYHIP_KEY && b.signature !== (await sha256(env.PAYHIP_KEY))) return json({ ok: false }, 401);
      const sales = (await env.CK.get("sales", "json")) || [];
      const items = Array.isArray(b.items) ? b.items : [{ product_key: b.product_key, product_name: b.product_name, price: b.price }];
      sales.push({
        id: b.id || crypto.randomUUID(), type: b.type || "paid", date: b.date ? new Date(b.date * 1000 || b.date).toISOString() : new Date().toISOString(),
        total: Number(b.price || items.reduce((s, i) => s + Number(i.price || 0), 0)) / 100,   // Payhip sends cents
        currency: b.currency || "EUR", country: b.ip_country || b.country || "", items: items.map((i) => ({ key: i.product_key, name: i.product_name })),
        coupon: b.coupon_code || "", via: b.payment_type || "", email: String(b.email || "").toLowerCase(),
        paidItems: items.filter((i) => Number(i.price || 0) > 0).length,
      });
      await env.CK.put("sales", JSON.stringify(sales));
      return json({ ok: true });
    }

    // ---------- login ----------
    if (p === "/api/login" && req.method === "POST") {
      if (!env.ADMIN_KEY) return json({ ok: false, error: "setup" }, 503);
      const b = await req.json().catch(() => ({}));
      if (typeof b.key !== "string" || (await sha256(b.key)) !== (await sha256(env.ADMIN_KEY))) {
        await new Promise((r) => setTimeout(r, 800));
        return json({ ok: false }, 401);
      }
      const exp = String(Date.now() + 30 * 864e5);
      return json({ ok: true }, 200, { "set-cookie": `ck_admin=${exp}.${await hmac(env.ADMIN_KEY, exp)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${30 * 86400}` });
    }
    if (p === "/api/loyalty") {   // how many paid packs this email has bought (5 paid = 1 free pick)
      const em = String(url.searchParams.get("email") || "").trim().toLowerCase();
      if (!env.CK || !em) return json({ paid: 0, used: 0 });
      const sales = (await env.CK.get("sales", "json")) || [];
      const refunded = new Set(sales.filter((x) => x.type === "refunded").map((x) => x.id));
      const paid = sales.filter((x) => x.type !== "refunded" && !refunded.has(x.id) && x.email === em).reduce((n, x) => n + (x.paidItems || 0), 0);
      const used = Number((await env.CK.get("loyused:" + em)) || 0);
      const leads = (await env.CK.get("leads", "json")) || [];
      const deals = (await env.CK.get("packs", "json") || {}).deals || (await fileDeals(env, req)) || {};
      const bonus = leads.some((l) => l.email === em) ? Number(deals.signupBlocks || 0) : 0;
      return json({ paid: paid + bonus, used });
    }
    if (p === "/api/claim" && req.method === "POST") {
      if ((((env.CK && ((await env.CK.get("packs", "json")) || {}).deals) || (await fileDeals(env, req)) || {}).enabled === false) return json({ ok: false, error: "off" }, 403);   // one deal card per email per cooldown; tier is decided before the spin
      let b = {}; try { b = await req.json(); } catch (e) {}
      const email = String(b.email || "").trim().toLowerCase().slice(0, 200);
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({ ok: false, error: "email" }, 400);
      const deals = (env.CK && ((await env.CK.get("packs", "json")) || {}).deals) || (await fileDeals(env, req)) || {};
      const cards = deals.cards || [], ids = cards.map((c) => c.id);
      const now = Date.now(), day = 864e5;
      if (env.CK) {
        const old = await env.CK.get("card:" + email, "json");
        if (old && now - old.spun < (deals.cooldownDays || 30) * day) return json({ ok: true, again: true, card: old });
      }
      // tier comes from what this email has done with us (first-party), never from cookies
      let tier = "common";
      if (env.CK) {
        const leads = (await env.CK.get("leads", "json")) || [], l = leads.find((x) => x.email === email) || {};
        const sales = (await env.CK.get("sales", "json")) || [];
        const paid = sales.filter((x) => x.type !== "refunded" && x.email === email).reduce((n, x) => n + (x.paidItems || 0), 0);
        const age = l.first ? (now - Date.parse(l.first)) / day : 0, free = (l.packs || []).length;
        if (paid >= 2 || age >= 30) tier = "legend";
        else if (free >= 3 && paid === 0) tier = "epic";
        else if (free >= 2 || age >= 1) tier = "rare";
      }
      if (!ids.includes(tier)) tier = ids[0];
      const code = "CK-" + [...crypto.getRandomValues(new Uint8Array(6))].map((x) => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[x % 32]).join("");
      const card = { tier, code, email, spun: now, exp: now + (deals.expiryDays || 7) * day, used: false };
      if (env.CK) await env.CK.put("card:" + email, JSON.stringify(card), { expirationTtl: 60 * 60 * 24 * 90 });
      return json({ ok: true, card });
    }
    if (p === "/api/ev" && req.method === "POST") {
      const D = await db(env); if (!D) return json({ ok: true });
      let b = {}; try { b = JSON.parse(await req.text()); } catch (e) { return json({ ok: false }, 400); }
      const evs = (Array.isArray(b.e) ? b.e : []).filter((x) => x && EV_TYPES.has(x.t)).slice(0, 20);
      if (!evs.length) return json({ ok: true });
      const now = Date.now(), day = new Date(now).toISOString().slice(0, 10), country = (req.cf && req.cf.country) || "";
      const dev = /Mobi|Android|iPhone|iPad/i.test(req.headers.get("user-agent") || "") ? "phone" : "desktop";
      const ins = D.prepare("INSERT INTO ev (ts, day, t, pack, x, ref, vid, sid, country, dev, val) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
      await D.batch(evs.map((x) => ins.bind(now, day, x.t, clip(x.pack, 60), clip(x.x, 120), clip(b.ref, 40), clip(b.vid, 40), clip(b.sid, 40), country, dev, Number(x.val) || null)));
      return json({ ok: true });
    }
    if (p.startsWith("/r/")) {   // short tracking link: corekult.com/r/<code>
      const code = decodeURIComponent(p.slice(3)).toLowerCase();
      const links = (env.CK && (await env.CK.get("links", "json"))) || [];
      const l = links.find((x) => x.code === code);
      const to = new URL(l && l.pack ? "/pack/" + encodeURIComponent(l.pack) : "/", req.url);
      if (l) to.searchParams.set("ref", l.code);
      return Response.redirect(to.toString(), 302);
    }
    if (p === "/api/fx") return json({ base: "EUR", rates: await fxRates() }, 200, { "cache-control": "public, max-age=3600" });
    if (p === "/api/free" && req.method === "POST") {   // free pack for an email: save the email for Eman
      let b = {}; try { b = await req.json(); } catch (e) {}
      const email = String(b.email || "").trim().toLowerCase().slice(0, 200), pack = String(b.pack || "").slice(0, 80);
      let isNew = !env.CK;
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({ ok: false, error: "email" }, 400);
      if (env.CK) {
        const leads = (await env.CK.get("leads", "json")) || [];
        let l = leads.find((x) => x.email === email);
        if (!l) { l = { email, packs: [], first: new Date().toISOString(), country: (req.cf && req.cf.country) || "" }; leads.push(l); isNew = true; }
        if (pack && !l.packs.includes(pack)) l.packs.push(pack);
        l.last = new Date().toISOString();
        await env.CK.put("leads", JSON.stringify(leads));
      }
      return json({ ok: true, isNew });
    }
    if (p === "/api/logout") return json({ ok: true }, 200, { "set-cookie": "ck_admin=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0" });

    // ---------- private pages + api ----------
    const priv = p === "/admin" || p.startsWith("/admin/") || p === "/work" || p.startsWith("/work/") || p.startsWith("/api/admin/");
    if (priv) {
      const ok = await isAdmin(req, env);
      if (!ok) {
        if (p.startsWith("/api/")) return json({ ok: false, error: env.ADMIN_KEY ? "login" : "setup" }, 401);
        return Response.redirect(new URL("/login?next=" + encodeURIComponent(p), req.url).toString(), 302);
      }
      if (p === "/api/admin/state") {
        return json({ packs: await loadPacks(env, req), sales: env.CK ? (await env.CK.get("sales", "json")) || [] : [], leads: env.CK ? (await env.CK.get("leads", "json")) || [] : [], storage: !!env.CK, webhook: new URL("/api/payhip", req.url).toString() });
      }
      if (p === "/api/admin/stats") {
        const days = Math.min(365, Math.max(1, Number(url.searchParams.get("days")) || 30));
        const from = new Date(Date.now() - (days - 1) * 864e5).toISOString().slice(0, 10);
        const D = await db(env);
        const links = (env.CK && (await env.CK.get("links", "json"))) || [];
        const st = await settings(env);
        if (!D) return json({ ok: true, db: false, links, settings: st });
        const q = (sql, ...a) => D.prepare(sql).bind(...a).all().then((r) => r.results);
        const [perDay, totals, visitors, returning, packs, plays, sounds, countries, devs, refs] = await Promise.all([
          q("SELECT day, t, COUNT(*) n FROM ev WHERE day >= ? GROUP BY day, t", from),
          q("SELECT t, COUNT(*) n FROM ev WHERE day >= ? GROUP BY t", from),
          q("SELECT COUNT(DISTINCT vid) n, COUNT(DISTINCT sid) s FROM ev WHERE day >= ? AND vid IS NOT NULL", from),
          q("SELECT COUNT(*) n FROM (SELECT vid FROM ev WHERE day >= ? AND vid IS NOT NULL GROUP BY vid HAVING COUNT(DISTINCT sid) > 1)", from),
          q("SELECT pack, t, COUNT(*) n FROM ev WHERE day >= ? AND pack IS NOT NULL GROUP BY pack, t", from),
          q("SELECT pack, x, COUNT(*) n FROM ev WHERE day >= ? AND t = 'play' GROUP BY pack, x ORDER BY n DESC LIMIT 15", from),
          q("SELECT COUNT(*) n FROM ev WHERE day >= ? AND t = 'play'", from),
          q("SELECT country, COUNT(*) n FROM ev WHERE day >= ? AND t = 'view' GROUP BY country ORDER BY n DESC LIMIT 12", from),
          q("SELECT dev, COUNT(*) n FROM ev WHERE day >= ? AND t = 'view' GROUP BY dev", from),
          q("SELECT ref, t, COUNT(*) n, SUM(val) v FROM ev WHERE day >= ? AND ref IS NOT NULL GROUP BY ref, t", from),
        ]);
        return json({ ok: true, db: true, days, from, perDay, totals, visitors: visitors[0] || {}, returning: (returning[0] || {}).n || 0, packs, plays, sounds, countries, devs, refs, links, settings: st });
      }
      if (p === "/api/admin/links" && req.method === "POST") {
        if (!env.CK) return json({ ok: false, error: "storage" }, 503);
        const b = await req.json().catch(() => ({}));
        const links = (await env.CK.get("links", "json")) || [];
        if (b.del) { await env.CK.put("links", JSON.stringify(links.filter((l) => l.code !== b.del))); return json({ ok: true }); }
        const name = String(b.name || "").trim().slice(0, 60); if (!name) return json({ ok: false, error: "name" }, 400);
        let code = (String(b.code || name).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "link").slice(0, 30), base = code, n = 1;
        while (links.some((l) => l.code === code)) code = base + "-" + ++n;
        const l = { code, name, pack: b.pack ? String(b.pack).slice(0, 80) : "", created: new Date().toISOString() };
        links.push(l); await env.CK.put("links", JSON.stringify(links));
        return json({ ok: true, link: l });
      }
      if (p === "/api/admin/settings" && req.method === "POST") {
        if (!env.CK) return json({ ok: false, error: "storage" }, 503);
        const b = await req.json().catch(() => ({}));
        const st = await settings(env);
        if ("clarityId" in b) st.clarityId = String(b.clarityId || "").replace(/[^a-z0-9]/gi, "").slice(0, 20);
        await env.CK.put("settings", JSON.stringify(st));
        return json({ ok: true, settings: st });
      }
      if (p === "/api/admin/packs" && req.method === "PUT") {
        if (!env.CK) return json({ ok: false, error: "storage" }, 503);
        const d = await req.json().catch(() => null);
        if (!d || !Array.isArray(d.products) || !Array.isArray(d.worlds)) return json({ ok: false }, 400);
        const old = await env.CK.get("packs");
        if (old) await env.CK.put("packs:prev", old);           // one step undo
        await env.CK.put("packs", JSON.stringify(d));
        return json({ ok: true });
      }
      if (p === "/api/admin/undo" && req.method === "POST") {
        if (!env.CK) return json({ ok: false }, 503);
        const prev = await env.CK.get("packs:prev");
        if (!prev) return json({ ok: false }, 404);
        await env.CK.put("packs", prev);
        return json({ ok: true });
      }
      if (p === "/api/admin/upload" && req.method === "POST") {
        if (!env.CK) return json({ ok: false, error: "storage" }, 503);
        const type = req.headers.get("content-type") || "application/octet-stream";
        const raw = (url.searchParams.get("name") || "file").toLowerCase().replace(/[^a-z0-9._-]+/g, "-").slice(-80);
        const name = Date.now().toString(36) + "-" + raw;
        const buf = await req.arrayBuffer();
        if (buf.byteLength > 20e6) return json({ ok: false, error: "too big" }, 413);
        await env.CK.put("file:" + name, buf, { metadata: { type } });
        return json({ ok: true, url: "/f/" + name });
      }
      if (p.startsWith("/api/")) return json({ ok: false }, 404);
      return env.ASSETS.fetch(req);
    }
    // pack pages: /pack/<id> all use pack.html
    if (p.startsWith("/pack/")) return env.ASSETS.fetch(new Request(new URL("/pack", req.url), req));
    if (p === "/pack" || p === "/pack.html") return Response.redirect(new URL("/", req.url).toString(), 302);
    // the .html names of private pages are private too
    if (p === "/admin.html" || p === "/work.html") return Response.redirect(new URL(p.replace(".html", ""), req.url).toString(), 302);

    return env.ASSETS.fetch(req);
  },
};
