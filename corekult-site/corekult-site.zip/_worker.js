// COREKULT backend (Cloudflare Pages advanced mode).
// Needs in Cloudflare Pages > corekult > Settings:
//   KV binding  CK         -> KV namespace "corekult"   (pack data, uploads, sales)
//   Secret      ADMIN_KEY  -> Eman's admin key (Eman types it, nobody else)
//   Secret      PAYHIP_KEY -> optional, Payhip API key, to check webhook signatures
// Without CK the shop falls back to the static products.json and admin is read-only.

const JSON_H = { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" };
const json = (d, s = 200, h = {}) => new Response(JSON.stringify(d), { status: s, headers: { ...JSON_H, ...h } });
const enc = new TextEncoder();

async function hmac(key, msg) {
  const k = await crypto.subtle.importKey("raw", enc.encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", k, enc.encode(msg));
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function sha256(s) {
  const d = await crypto.subtle.digest("SHA-256", enc.encode(s));
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
function cookie(req, name) {
  const m = (req.headers.get("cookie") || "").match(new RegExp("(?:^|;\\s*)" + name + "=([^;]+)"));
  return m ? m[1] : null;
}
// session cookie = "<expiry>.<hmac(ADMIN_KEY, expiry)>"
async function isAdmin(req, env) {
  if (!env.ADMIN_KEY) return false;
  const c = cookie(req, "ck_admin");
  if (!c) return false;
  const [exp, sig] = c.split(".");
  if (!exp || !sig || +exp < Date.now()) return false;
  return sig === (await hmac(env.ADMIN_KEY, exp));
}

async function loadPacks(env, req) {
  if (env.CK) {
    const d = await env.CK.get("packs", "json");
    if (d) return d;
  }
  const r = await env.ASSETS.fetch(new Request(new URL("/products.json", req.url)));
  const d = await r.json();
  d.products.forEach((p) => { p.status = p.status || "live"; });
  return d;
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const p = url.pathname;

    // ---------- public ----------
    if (p === "/api/products") {
      const d = await loadPacks(env, req);
      const products = d.products.filter((x) => (x.status || "live") === "live")
        .map(({ notes, reviewUrl, status, ...x }) => ({ ...x, sounds: (x.sounds || []).filter((s) => !s.hidden) }));
      return json({ currency: d.currency, worlds: d.worlds, products });
    }
    if (p.startsWith("/f/")) {                       // uploaded covers / previews
      if (!env.CK) return new Response("not found", { status: 404 });
      const o = await env.CK.getWithMetadata("file:" + decodeURIComponent(p.slice(3)), "arrayBuffer");
      if (!o.value) return new Response("not found", { status: 404 });
      return new Response(o.value, { headers: { "content-type": (o.metadata && o.metadata.type) || "application/octet-stream", "cache-control": "public, max-age=31536000, immutable" } });
    }
    if (p === "/api/payhip" && req.method === "POST") {   // Payhip webhook: paid / refunded
      if (!env.CK) return json({ ok: false }, 503);
      const b = await req.json().catch(() => null);
      if (!b) return json({ ok: false }, 400);
      if (env.PAYHIP_KEY && b.signature !== (await sha256(env.PAYHIP_KEY))) return json({ ok: false }, 401);
      const sales = (await env.CK.get("sales", "json")) || [];
      const items = Array.isArray(b.items) ? b.items : [{ product_key: b.product_key, product_name: b.product_name, price: b.price }];
      sales.push({
        id: b.id || crypto.randomUUID(), type: b.type || "paid", date: b.date ? new Date(b.date * 1000 || b.date).toISOString() : new Date().toISOString(),
        total: Number(b.price || items.reduce((s, i) => s + Number(i.price || 0), 0)) / 100,   // Payhip sends cents
        currency: b.currency || "EUR", country: b.ip_country || b.country || "", items: items.map((i) => ({ key: i.product_key, name: i.product_name })),
        coupon: b.coupon_code || "", via: b.payment_type || "",
      });
      await env.CK.put("sales", JSON.stringify(sales));
      return json({ ok: true });
    }

    // ---------- login ----------
    if (p === "/api/login" && req.method === "POST") {
      if (!env.ADMIN_KEY) return json({ ok: false, error: "setup" }, 503);
      const b = await req.json().catch(() => ({}));
      if (typeof b.key !== "string" || (await sha256(b.key)) !== (await sha256(env.ADMIN_KEY))) {
        await new Promise((r) => setTimeout(r, 800));
        return json({ ok: false }, 401);
      }
      const exp = String(Date.now() + 30 * 864e5);
      return json({ ok: true }, 200, { "set-cookie": `ck_admin=${exp}.${await hmac(env.ADMIN_KEY, exp)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${30 * 86400}` });
    }
    if (p === "/api/logout") return json({ ok: true }, 200, { "set-cookie": "ck_admin=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0" });

    // ---------- private pages + api ----------
    const priv = p === "/admin" || p.startsWith("/admin/") || p === "/work" || p.startsWith("/work/") || p.startsWith("/api/admin/");
    if (priv) {
      const ok = await isAdmin(req, env);
      if (!ok) {
        if (p.startsWith("/api/")) return json({ ok: false, error: env.ADMIN_KEY ? "login" : "setup" }, 401);
        return Response.redirect(new URL("/login?next=" + encodeURIComponent(p), req.url).toString(), 302);
      }
      if (p === "/api/admin/state") {
        return json({ packs: await loadPacks(env, req), sales: env.CK ? (await env.CK.get("sales", "json")) || [] : [], storage: !!env.CK, webhook: new URL("/api/payhip", req.url).toString() });
      }
      if (p === "/api/admin/packs" && req.method === "PUT") {
        if (!env.CK) return json({ ok: false, error: "storage" }, 503);
        const d = await req.json().catch(() => null);
        if (!d || !Array.isArray(d.products) || !Array.isArray(d.worlds)) return json({ ok: false }, 400);
        const old = await env.CK.get("packs");
        if (old) await env.CK.put("packs:prev", old);           // one step undo
        await env.CK.put("packs", JSON.stringify(d));
        return json({ ok: true });
      }
      if (p === "/api/admin/undo" && req.method === "POST") {
        if (!env.CK) return json({ ok: false }, 503);
        const prev = await env.CK.get("packs:prev");
        if (!prev) return json({ ok: false }, 404);
        await env.CK.put("packs", prev);
        return json({ ok: true });
      }
      if (p === "/api/admin/upload" && req.method === "POST") {
        if (!env.CK) return json({ ok: false, error: "storage" }, 503);
        const type = req.headers.get("content-type") || "application/octet-stream";
        const raw = (url.searchParams.get("name") || "file").toLowerCase().replace(/[^a-z0-9._-]+/g, "-").slice(-80);
        const name = Date.now().toString(36) + "-" + raw;
        const buf = await req.arrayBuffer();
        if (buf.byteLength > 20e6) return json({ ok: false, error: "too big" }, 413);
        await env.CK.put("file:" + name, buf, { metadata: { type } });
        return json({ ok: true, url: "/f/" + name });
      }
      if (p.startsWith("/api/")) return json({ ok: false }, 404);
      return env.ASSETS.fetch(req);
    }
    // the .html names of private pages are private too
    if (p === "/admin.html" || p === "/work.html") return Response.redirect(new URL(p.replace(".html", ""), req.url).toString(), 302);

    return env.ASSETS.fetch(req);
  },
};
