/* COREKULT mastering engine worker. Runs Matchering 2 (GPLv3) with Pyodide, fully on this device.
   Source + licence: /tools/mastering/engine/SOURCE.txt */
const PYO = "https://cdn.jsdelivr.net/pyodide/v0.27.7/full/";
importScripts(PYO + "pyodide.js", "lame.min.js");
let py = null, booting = null;
self.ck_progress = (pct, label) => postMessage({ type: "progress", pct, label });
function boot() {
  if (booting) return booting;
  booting = (async () => {
    postMessage({ type: "boot", pct: 5, label: "starting engine" });
    py = await loadPyodide({ indexURL: PYO });
    postMessage({ type: "boot", pct: 35, label: "loading DSP" });
    await py.loadPackage(["numpy", "scipy"], { messageCallback: () => {} });
    postMessage({ type: "boot", pct: 85, label: "loading Matchering" });
    const z = await (await fetch("ck_engine.zip?v=1")).arrayBuffer();
    py.unpackArchive(z, "zip", { extractDir: "/home/pyodide/ck" });
    py.runPython("import sys; sys.path.insert(0, '/home/pyodide/ck'); import ck_boot");
    postMessage({ type: "ready" });
  })();
  return booting;
}
function interleave(L, R) { const o = new Float32Array(L.length * 2); for (let i = 0, j = 0; i < L.length; i++) { o[j++] = L[i]; o[j++] = R[i]; } return o; }
function wav24(L, R, sr) {
  const n = L.length, data = n * 6, b = new ArrayBuffer(44 + data), v = new DataView(b);
  const s = (o, t) => { for (let i = 0; i < t.length; i++) v.setUint8(o + i, t.charCodeAt(i)); };
  s(0, "RIFF"); v.setUint32(4, 36 + data, true); s(8, "WAVE"); s(12, "fmt "); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 2, true);
  v.setUint32(24, sr, true); v.setUint32(28, sr * 6, true); v.setUint16(32, 6, true); v.setUint16(34, 24, true); s(36, "data"); v.setUint32(40, data, true);
  const u = new Uint8Array(b); let p = 44;
  for (let i = 0; i < n; i++) for (const c of [L[i], R[i]]) { let x = Math.round(Math.max(-1, Math.min(1, c)) * 8388607); u[p++] = x & 255; u[p++] = (x >> 8) & 255; u[p++] = (x >> 16) & 255; }
  return new Blob([b], { type: "audio/wav" });
}
function mp3(L, R, sr) {
  const enc = new lamejs.Mp3Encoder(2, sr, 320), B = 1152, out = [], l = new Int16Array(B), r = new Int16Array(B);
  for (let i = 0; i < L.length; i += B) {
    const n = Math.min(B, L.length - i);
    for (let k = 0; k < n; k++) { l[k] = Math.max(-1, Math.min(1, L[i + k])) * 32767; r[k] = Math.max(-1, Math.min(1, R[i + k])) * 32767; }
    const d = enc.encodeBuffer(n === B ? l : l.subarray(0, n), n === B ? r : r.subarray(0, n)); if (d.length) out.push(new Uint8Array(d));
    if ((i / B) % 400 === 0) postMessage({ type: "encode", pct: Math.round(i / L.length * 100) });
  }
  const e = enc.flush(); if (e.length) out.push(new Uint8Array(e));
  return new Blob(out, { type: "audio/mpeg" });
}
onmessage = async (ev) => {
  const m = ev.data;
  try {
    if (m.type === "boot") { await boot(); return; }
    if (m.type === "master") {
      await boot();
      const t0 = performance.now();
      postMessage({ type: "progress", pct: 10, label: "reading your song" });
      py.FS.writeFile("/tmp/t.f32", new Uint8Array(interleave(m.L, m.R).buffer));
      if (m.refL) py.FS.writeFile("/tmp/r.f32", new Uint8Array(interleave(m.refL, m.refR).buffer));
      py.runPython("from ck_boot import ck_master");
      const len = py.runPython(`ck_master("/tmp/t.f32", "/tmp/r.f32", ${m.vibe ? JSON.stringify(m.vibe) : "None"})`);
      const raw = py.FS.readFile("/tmp/out.f32"), f = new Float32Array(raw.buffer, raw.byteOffset, raw.length / 4);
      const L = new Float32Array(len), R = new Float32Array(len);
      for (let i = 0, j = 0; i < len; i++) { L[i] = f[j++]; R[i] = f[j++]; }
      try { py.FS.unlink("/tmp/t.f32"); py.FS.unlink("/tmp/out.f32"); if (m.refL) py.FS.unlink("/tmp/r.f32"); } catch (e) {}
      postMessage({ type: "done", L, R, ms: Math.round(performance.now() - t0) }, [L.buffer, R.buffer]);
      return;
    }
    if (m.type === "export") {
      const blob = m.fmt === "wav" ? wav24(m.L, m.R, 44100) : mp3(m.L, m.R, 44100);
      postMessage({ type: "file", fmt: m.fmt, blob });
    }
  } catch (e) {
    postMessage({ type: "error", msg: String(e && e.message || e).split("\n").filter(Boolean).slice(-1)[0] });
  }
};
