/* COREKULT tools · Mastering page.
   The real master comes from Matchering 2 running in a Web Worker on this device (engine/worker.js).
   While it works, an instant Web Audio preview (EQ + level + limiter guessed from the same reference) plays right away. */
(() => {
const $m = (s) => document.querySelector(s);
$m("#yr").textContent = new Date().getFullYear();
const SR = 44100, MAX_MIN = 6, MAX_REF_S = 300;
// same curves as engine ck_vibes.py: mid dB at BANDS (rel. 500 Hz), side offset, target RMS dBFS
const BANDS = [31, 50, 80, 125, 200, 315, 500, 800, 1250, 2000, 3150, 5000, 8000, 12500, 16000, 20000];
const VIBES = [
  { id: "crystal", n: "Crystal", d: "bright, airy, clean", c: "#9fe7ff", pack: "crystal-core-i", mid: [10, 10, 8, 6, 3, 1, 0, -3, -6, -8, -10, -12, -13, -15, -20, -28], rms: -8.5 },
  { id: "rage", n: "Rage", d: "huge 808, loud, hard", c: "#ff5a5a", pack: "travis-core-i", mid: [16, 15, 12, 8, 3, 1, 0, -2, -5, -7, -9, -12, -14, -17, -24, -32], rms: -7 },
  { id: "hyperpop", n: "Hyperpop", d: "glossy, bright, loud", c: "#ff8ad8", pack: "2hollcore-i", mid: [11, 11, 9, 6, 3, 1, 0, -1, -3, -5, -7, -9, -11, -13, -18, -26], rms: -7 },
  { id: "dreamcore", n: "Dreamcore", d: "warm, wide, soft", c: "#b9a4ff", pack: "dreamcore-i", mid: [9, 9, 7, 5, 3, 1, 0, -3, -7, -10, -13, -16, -19, -23, -30, -38], rms: -11 },
  { id: "lean", n: "Lean", d: "dark, hazy, washed", c: "#7fd1a8", pack: "dreamcore-ii", mid: [10, 11, 9, 7, 4, 2, 0, -4, -8, -12, -16, -20, -25, -30, -38, -46], rms: -10 },
  { id: "travis", n: "Travis", d: "dark, big sub, wide", c: "#e4ff3a", pack: "travis-core-i", mid: [15, 14, 11, 7, 3, 1, 0, -3, -7, -10, -13, -17, -20, -24, -31, -39], rms: -8 },
];
let tab = "vibe", vibe = "crystal", T = null, R = null, tName = "", masterL = null, masterR = null, masterId = "", paid = false, busy = false;
let ctx = null, src = null, chain = null, playing = false, startAt = 0, offset = 0, ab = "b", raf = 0;
const files = {};

/* ---------- vibes ---------- */
$m("#vibes").innerHTML = VIBES.map((v) => `<button class="vb${v.id === vibe ? " on" : ""}" data-vibe="${v.id}" style="--vc:${v.c}"><b>${v.n}</b><span>${v.d}</span></button>`).join("");
$m("#vibes").onclick = (e) => { const b = e.target.closest("[data-vibe]"); if (!b) return; vibe = b.dataset.vibe; document.querySelectorAll(".vb").forEach((x) => x.classList.toggle("on", x === b)); ready(); };
document.querySelectorAll("[data-tab]").forEach((b) => b.onclick = () => {
  tab = b.dataset.tab; document.querySelectorAll("[data-tab]").forEach((x) => x.classList.toggle("on", x === b));
  $m("#vibes").hidden = tab !== "vibe"; $m("#refBox").hidden = tab !== "ref"; ready();
});

/* ---------- files ---------- */
async function decode(file) {
  const buf = await file.arrayBuffer();
  const oc = new (window.OfflineAudioContext || window.webkitOfflineAudioContext)(2, SR, SR);   // decodes + resamples to 44.1 kHz
  const ab = await new Promise((ok, bad) => { const p = oc.decodeAudioData(buf, ok, bad); if (p && p.then) p.then(ok, bad); });
  const L = ab.getChannelData(0), Rr = ab.numberOfChannels > 1 ? ab.getChannelData(1) : ab.getChannelData(0);
  return { L: new Float32Array(L), R: new Float32Array(Rr), dur: ab.length / SR };
}
const fmt = (s) => Math.floor(s / 60) + ":" + String(Math.floor(s % 60)).padStart(2, "0");
function wireDrop(dropSel, inputSel, onFile) {
  const d = $m(dropSel), inp = $m(inputSel);
  inp.onchange = () => inp.files[0] && onFile(inp.files[0]);
  ["dragenter", "dragover"].forEach((t) => d.addEventListener(t, (e) => { e.preventDefault(); d.classList.add("over"); }));
  ["dragleave", "drop"].forEach((t) => d.addEventListener(t, () => d.classList.remove("over")));
  d.addEventListener("drop", (e) => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) onFile(f); });
}
wireDrop("#dropT", "#fileT", async (f) => {
  $m("#nameT").textContent = "Reading " + f.name + "…"; engine();   // start fetching the engine now, while they choose
  try {
    const a = await decode(f);
    if (a.dur > MAX_MIN * 60) { T = null; $m("#nameT").textContent = f.name; $m("#infoT").textContent = `That's ${fmt(a.dur)}. Max ${MAX_MIN} minutes for now.`; $m("#dropT").classList.remove("has"); return ready(); }
    if (a.dur < 3) throw 0;
    T = a; tName = f.name.replace(/\.[^.]+$/, "");
    $m("#nameT").textContent = f.name; $m("#infoT").textContent = fmt(a.dur) + " · ready"; $m("#dropT").classList.add("has");
  } catch (e) { T = null; $m("#nameT").textContent = "Couldn't read that file"; $m("#infoT").textContent = "Try a WAV or MP3."; $m("#dropT").classList.remove("has"); }
  ready();
});
wireDrop("#dropR", "#fileR", async (f) => {
  $m("#nameR").textContent = "Reading " + f.name + "…";
  try {
    const a = await decode(f); if (a.dur < 3) throw 0;
    if (a.dur > MAX_REF_S) { const s = Math.floor((a.dur / 2 - MAX_REF_S / 2) * SR), e = s + MAX_REF_S * SR; a.L = a.L.slice(s, e); a.R = a.R.slice(s, e); a.dur = MAX_REF_S; }
    R = a; $m("#nameR").textContent = f.name; $m("#dropR").classList.add("has");
  } catch (e) { R = null; $m("#nameR").textContent = "Couldn't read that file. Try a WAV or MP3."; $m("#dropR").classList.remove("has"); }
  ready();
});
$m("#rights").onchange = ready;
function ready() {
  const ok = !!T && $m("#rights").checked && (tab === "vibe" || !!R) && !busy;
  $m("#goBtn").disabled = !ok;
  $m("#goNote").className = "gonote";
  $m("#goNote").textContent = busy ? "Mastering…" : !T ? "Add your song first." : !$m("#rights").checked ? "Tick the box to confirm it's your song." : tab === "ref" && !R ? "Add your reference song." : "Free to listen. Download MP3 + WAV for 50 PTS.";
}

/* ---------- engine (Web Worker) ---------- */
let W = null, bootPct = 0, engineReady = false, onDone = null;
function engine() {
  if (W) return W;
  W = new Worker("/tools/mastering/engine/worker.js?v=1");
  W.onmessage = (e) => {
    const m = e.data;
    if (m.type === "boot") { bootPct = m.pct; if (busy) prog(Math.round(m.pct * 0.3), "Loading the engine (first time only)…"); }
    if (m.type === "ready") { engineReady = true; }
    if (m.type === "progress") stage(m.pct, m.label);
    if (m.type === "done") { onDone && onDone(m); }
    if (m.type === "file") { files[m.fmt] && files[m.fmt].ok(m.blob); delete files[m.fmt]; }
    if (m.type === "encode") $m("#dlMsg") && ($m("#dlMsg").textContent = `Making your MP3… ${m.pct}%`);
    if (m.type === "error") fail(m.msg);
  };
  W.onerror = () => fail("engine");
  W.postMessage({ type: "boot" });
  return W;
}

/* ---------- progress ---------- */
let stageFloor = 0, est = 15, t0 = 0, tick = 0;
const LABELS = { "matching levels": "Matching loudness…", "matching frequencies": "Matching tone (EQ)…", "correcting levels": "Matching stereo width…", "final processing": "Limiter + final polish…" };
function prog(p, tx) { $m("#progBar").style.width = Math.min(100, p) + "%"; if (tx) $m("#progTx").textContent = tx; }
function stage(p, label) { stageFloor = 30 + p * 0.65; if (LABELS[label]) $m("#progTx").textContent = LABELS[label]; }
function runTicker() {
  clearInterval(tick);
  tick = setInterval(() => {
    if (!busy) return clearInterval(tick);
    if (!engineReady) return;
    const s = (performance.now() - t0) / 1000, guess = 30 + 65 * (1 - Math.exp(-s / (est * 0.55)));
    prog(Math.max(stageFloor, Math.min(95, guess)));
  }, 200);
}
function fail(msg) {
  busy = false; clearInterval(tick);
  $m("#prog").classList.remove("ok"); prog(100, "Something went wrong. Try a WAV file, or a shorter song.");
  $m("#pState").textContent = String(msg || "").slice(0, 80);
  ready();
}

/* ---------- instant preview: guess the EQ + level from the same reference ---------- */
function fft(re, im) {   // in-place radix-2
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) { let b = n >> 1; for (; j & b; b >>= 1) j ^= b; j ^= b; if (i < j) { [re[i], re[j]] = [re[j], re[i]]; [im[i], im[j]] = [im[j], im[i]]; } }
  for (let len = 2; len <= n; len <<= 1) {
    const a = -2 * Math.PI / len, wr = Math.cos(a), wi = Math.sin(a);
    for (let i = 0; i < n; i += len) { let cr = 1, ci = 0; for (let k = 0; k < len / 2; k++) {
      const ur = re[i + k], ui = im[i + k], xr = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci, xi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr;
      re[i + k] = ur + xr; im[i + k] = ui + xi; re[i + k + len / 2] = ur - xr; im[i + k + len / 2] = ui - xi;
      const t = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = t; } }
  }
}
function profile(a) {   // band levels (dB rel. 500 Hz) + loud-part RMS of the mid, from the loudest 0.5 s blocks
  const B = SR / 2 | 0, nb = Math.floor(a.L.length / B), rms = [];
  for (let b = 0; b < nb; b++) { let s = 0; for (let i = b * B; i < b * B + B; i += 4) { const m = (a.L[i] + a.R[i]) / 2; s += m * m; } rms.push([s / (B / 4), b]); }
  rms.sort((x, y) => y[0] - x[0]);
  const top = rms.slice(0, Math.max(4, Math.ceil(nb * 0.25)));
  const loud = 10 * Math.log10(top.reduce((s, x) => s + x[0], 0) / top.length + 1e-12);
  const N = 4096, acc = new Float64Array(N / 2), win = new Float64Array(N).map((_, i) => 0.5 - 0.5 * Math.cos(2 * Math.PI * i / N));
  const use = top.slice(0, 24);
  for (const [, b] of use) { const re = new Float64Array(N), im = new Float64Array(N), o = b * B; for (let i = 0; i < N; i++) re[i] = ((a.L[o + i] || 0) + (a.R[o + i] || 0)) / 2 * win[i]; fft(re, im); for (let k = 0; k < N / 2; k++) acc[k] += re[k] * re[k] + im[k] * im[k]; }
  const bdb = BANDS.map((c) => { let s = 0, n = 0; for (let k = 1; k < N / 2; k++) { const f = k * SR / N; if (f >= c / 1.26 && f < c * 1.26) { s += acc[k]; n++; } } return 10 * Math.log10(s / Math.max(1, n) + 1e-20); });
  return { bands: bdb.map((x) => x - bdb[6]), loud };
}
function previewParams() {
  const pt = profile(T);
  let ref;
  if (tab === "ref" && R) ref = profile(R);
  else { const v = VIBES.find((x) => x.id === vibe); ref = { bands: v.mid, loud: v.rms }; }
  const diff = (i0, i1) => { let s = 0; for (let i = i0; i <= i1; i++) s += ref.bands[i] - pt.bands[i]; return s / (i1 - i0 + 1); };
  const cl = (x, a) => Math.max(-a, Math.min(a, x * 0.8));
  return { low: cl(diff(1, 3), 8), lowmid: cl(diff(4, 5), 5), pres: cl(diff(9, 11), 6), air: cl(diff(12, 13), 7), gain: Math.max(-6, Math.min(14, ref.loud - pt.loud)) };
}
function buildChain(p) {
  const f = (type, freq, g, q) => { const n = ctx.createBiquadFilter(); n.type = type; n.frequency.value = freq; n.gain.value = g; if (q) n.Q.value = q; return n; };
  const nodes = [f("lowshelf", 110, p.low), f("peaking", 260, p.lowmid, 0.8), f("peaking", 3200, p.pres, 0.7), f("highshelf", 9000, p.air)];
  const g = ctx.createGain(); g.gain.value = Math.pow(10, p.gain / 20);
  const lim = ctx.createDynamicsCompressor(); lim.threshold.value = -1.5; lim.knee.value = 0; lim.ratio.value = 20; lim.attack.value = 0.002; lim.release.value = 0.12;
  nodes.reduce((a, b) => (a.connect(b), b)); nodes[nodes.length - 1].connect(g); g.connect(lim); lim.connect(ctx.destination);
  return { input: nodes[0] };
}

/* ---------- player ---------- */
let bufA = null, bufB = null;
function mkBuf(L, Rr) { const b = ctx.createBuffer(2, L.length, SR); b.copyToChannel(L, 0); b.copyToChannel(Rr, 1); return b; }
const dur = () => (bufA ? bufA.duration : 0);
const pos = () => (playing ? Math.min(dur(), offset + ctx.currentTime - startAt) : offset);
function stopSrc() { if (src) { src.onended = null; try { src.stop(); } catch (e) {} src.disconnect(); src = null; } }
function play(at) {
  stopSrc(); offset = at == null ? pos() : at; if (offset >= dur() - 0.05) offset = 0;
  const hq = !!bufB;
  src = ctx.createBufferSource(); src.buffer = ab === "b" && hq ? bufB : bufA;
  src.connect(ab === "b" && !hq ? chain.input : ctx.destination);
  src.onended = () => { if (playing && pos() >= dur() - 0.1) { playing = false; offset = 0; paintPlay(); } };
  startAt = ctx.currentTime; src.start(0, offset); playing = true; paintPlay(); loop();
}
function pause() { offset = pos(); playing = false; stopSrc(); paintPlay(); }
function paintPlay() { $m("#playIc").setAttribute("d", playing ? "M3 2h4v12H3zM9 2h4v12H9z" : "M4 2l10 6-10 6z"); }
function loop() { cancelAnimationFrame(raf); const step = () => { const p = pos(); $m("#phead").style.left = (p / (dur() || 1) * 100) + "%"; $m("#pTime").textContent = fmt(p) + " / " + fmt(dur()); if (playing) raf = requestAnimationFrame(step); }; step(); }
$m("#playBtn").onclick = () => { if (!ctx) return; ctx.resume(); playing ? pause() : play(); };
document.querySelectorAll("[data-ab]").forEach((b) => b.onclick = () => { ab = b.dataset.ab; document.querySelectorAll("[data-ab]").forEach((x) => x.classList.toggle("on", x === b)); if (playing) play(); drawWave(); });
$m(".wave").onclick = (e) => { if (!bufA) return; const r = e.currentTarget.getBoundingClientRect(); const t = (e.clientX - r.left) / r.width * dur(); playing ? play(t) : (offset = t, loop()); };
document.addEventListener("keydown", (e) => { if (e.code === "Space" && bufA && !/INPUT|TEXTAREA/.test(document.activeElement.tagName)) { e.preventDefault(); playing ? pause() : play(); } });
function drawWave() {
  const c = $m("#wave"), r = c.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1);
  c.width = Math.max(1, r.width * dpr); c.height = r.height * dpr; const g = c.getContext("2d"); g.clearRect(0, 0, c.width, c.height);
  const L = ab === "b" && masterL ? masterL : T.L, Rr = ab === "b" && masterR ? masterR : T.R, n = Math.floor(c.width / (2 * dpr)), step = Math.floor(L.length / n), mid = c.height / 2;
  g.fillStyle = ab === "b" ? (masterL ? "#e4ff3a" : "#8b6cf6") : "rgba(236,235,240,.45)";
  for (let i = 0; i < n; i++) { let m = 0; for (let k = i * step; k < (i + 1) * step; k += 16) { const v = Math.abs(L[k]) + Math.abs(Rr[k]); if (v > m) m = v; } const h = Math.max(1, m / 2 * mid * 0.95); g.fillRect(i * 2 * dpr, mid - h, dpr * 1.4, h * 2); }
}
window.addEventListener("resize", () => T && bufA && drawWave());

/* ---------- master it ---------- */
$m("#goBtn").onclick = () => {
  if (busy || !T) return;
  busy = true; ready(); paid = false; masterL = masterR = null; bufB = null;
  masterId = "m" + Date.now().toString(36);
  ctx = ctx || new (window.AudioContext || window.webkitAudioContext)({ sampleRate: SR }); ctx.resume();
  stopSrc(); playing = false; offset = 0; ab = "b"; document.querySelectorAll("[data-ab]").forEach((x) => x.classList.toggle("on", x.dataset.ab === "b"));
  bufA = mkBuf(T.L, T.R); chain = buildChain(previewParams());
  $m("#player").hidden = false; $m("#dl").hidden = true; $m("#prog").classList.remove("ok");
  $m("#pTag").textContent = "Instant preview"; $m("#pTag").classList.remove("hq"); $m("#pState").textContent = "Playing a quick preview while the real master is made";
  drawWave(); play(0);
  $m("#player").scrollIntoView({ behavior: "smooth", block: "nearest" });
  promo();
  est = Math.max(6, T.dur * 0.08); stageFloor = 0; t0 = performance.now();
  if (!engineReady) prog(Math.round(bootPct * 0.3), "Loading the engine (first time only)…"); else prog(30, "Reading your song…");
  const startTicker = () => { t0 = performance.now(); runTicker(); };
  if (engineReady) startTicker(); else { const w = setInterval(() => { if (!busy) return clearInterval(w); if (engineReady) { clearInterval(w); startTicker(); } }, 150); }
  const msg = { type: "master", L: T.L.slice(), R: T.R.slice(), vibe: tab === "vibe" ? vibe : null };
  if (tab === "ref" && R) { msg.refL = R.L.slice(); msg.refR = R.R.slice(); }
  onDone = (m) => {
    busy = false; clearInterval(tick); ready();
    masterL = m.L; masterR = m.R; bufB = mkBuf(m.L, m.R);
    $m("#prog").classList.add("ok"); prog(100, `HQ master ready · ${(m.ms / 1000).toFixed(1)} s`);
    $m("#pTag").textContent = "HQ master"; $m("#pTag").classList.add("hq"); $m("#pState").textContent = "Switch Original / Mastered while it plays";
    if (playing) play(); drawWave(); coinSafe();
    showDl();
    trackSafe("master", tab === "vibe" ? vibe : "ref");
  };
  engine().postMessage(msg, [msg.L.buffer, msg.R.buffer].concat(msg.refL ? [msg.refL.buffer, msg.refR.buffer] : []));
};
const coinSafe = () => { try { if (typeof coin === "function" && !(typeof muted === "function" && muted())) coin(); } catch (e) {} };
const trackSafe = (t, x) => { try { if (typeof track === "function") track(t, null, x); } catch (e) {} };

/* ---------- pack promo (quiet, matches the vibe) ---------- */
function promo() {
  try {
    const all = typeof ALLP !== "undefined" ? ALLP.filter((p) => !p.freebie) : [];
    if (!all.length) return;
    const want = tab === "vibe" ? VIBES.find((v) => v.id === vibe).pack : null;
    const p = all.find((x) => x.id === want) || all[Math.floor(Math.random() * all.length)];
    const el = $m("#promo"); el.hidden = false;
    el.innerHTML = `<img src="${esc(abs(p.cover))}" alt=""><div><small>Made for this sound</small><b>${esc(p.name)}</b><span>${p.sounds ? p.sounds.length + " sounds · " : ""}${typeof show === "function" ? show(p.price) : ""}</span></div><a class="btn sm" href="/pack/${encodeURIComponent(p.id)}">See pack</a>`;
  } catch (e) {}
}

/* ---------- download: 50 PTS for MP3 + WAV ---------- */
const email = () => { try { return localStorage.getItem("ck-email") || ""; } catch (e) { return ""; } };
function showDl() {
  $m("#dl").hidden = false;
  if (paid) return paintFiles();
  const em = email();
  if (!em) {
    $m("#dlBody").innerHTML = `<div class="join"><b>Join the KULT free: +400 PTS = 8 masters</b>
      <div class="dlf" style="margin-top:8px"><input id="dlEmail" type="email" autocomplete="email" placeholder="you@email.com" data-clarity-mask="true"><button class="btn acid" id="dlJoin">Join free</button></div>
      <label class="optin"><input type="checkbox" id="dlDrops"><span>Also email me new drops and free packs (max 2 a month)</span></label>
      <small>No card, no password: your points are saved to this email. +200 PTS every week, and we'll email you when they're ready (unsubscribe any time).</small>
      <div class="dlm" id="dlMsg"></div></div>`;
    $m("#dlJoin").onclick = join;
    return;
  }
  const pts = typeof LOY !== "undefined" && LOY && LOY.pts != null ? LOY.pts : null;
  $m("#dlBody").innerHTML = `${pts != null ? `<div class="ptsline">Your points <em>${pts}</em> · ${Math.floor(pts / 50)} masters</div>` : ""}
    <div class="dlr"><button class="btn acid" id="dlPay">Download MP3 + WAV · 50 PTS</button></div>
    <div class="dlm" id="dlMsg">Saved to <b>${esc(em)}</b>. <button class="ckl" id="dlSwap">Not you?</button></div>`;
  $m("#dlPay").onclick = spend;
  $m("#dlSwap").onclick = () => { try { localStorage.removeItem("ck-email"); } catch (e) {} showDl(); };
}
function join() {
  const em = ($m("#dlEmail").value || "").trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em)) { $m("#dlMsg").className = "dlm err"; $m("#dlMsg").textContent = "Check the email."; return; }
  $m("#dlJoin").disabled = true;
  fetch("/api/free", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ email: em, meter: true, drops: !!$m("#dlDrops").checked }) })
    .then((r) => r.json()).then(() => {
      try { localStorage.setItem("ck-email", em); } catch (e) {}
      trackSafe("claim", "master");
      return typeof loadLoyalty === "function" ? loadLoyalty() : null;
    }).then(() => showDl()).catch(() => { $m("#dlJoin").disabled = false; $m("#dlMsg").textContent = "Couldn't connect. Try again."; });
}
function spend() {
  const em = email(); $m("#dlPay").disabled = true;
  fetch("/api/spend", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ email: em, tool: "master", ref: masterId + ":" + tName.slice(0, 40) }) })
    .then((r) => r.json().then((d) => ({ s: r.status, d })))
    .then(({ s, d }) => {
      if (d.ok) { paid = true; if (typeof loadLoyalty === "function") loadLoyalty(); paintFiles(); return; }
      $m("#dlPay").disabled = false;
      const m = $m("#dlMsg"); m.className = "dlm err";
      if (d.error === "low") m.innerHTML = `You have ${d.pts} PTS and a master is ${d.cost}. You get +200 free every week, and +200 with every pack you buy.`;
      else if (d.error === "noclaim") { try { localStorage.removeItem("ck-email"); } catch (e) {} showDl(); $m("#dlEmail").value = em; }
      else m.textContent = "Couldn't connect. Try again.";
    }).catch(() => { $m("#dlPay").disabled = false; $m("#dlMsg").textContent = "Couldn't connect. Try again."; });
}
function make(fmt) { return new Promise((ok) => { files[fmt] = { ok }; engine().postMessage({ type: "export", fmt, L: masterL, R: masterR }); }); }
function save(blob, name) { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000); }
function paintFiles() {
  const base = (tName || "song") + " (COREKULT master)";
  $m("#dlBody").innerHTML = `<div class="dlr"><button class="btn acid" data-f="mp3">Download MP3 320</button><button class="btn acid" data-f="wav">Download WAV 24-bit</button></div><div class="dlm" id="dlMsg">Paid ✓ Download both as often as you like until you close this page.</div>`;
  $m("#dlBody").querySelectorAll("[data-f]").forEach((b) => b.onclick = async () => {
    const f = b.dataset.f; b.disabled = true; $m("#dlMsg").textContent = f === "wav" ? "Making your WAV…" : "Making your MP3…";
    const blob = await make(f); save(blob, base + "." + f); b.disabled = false; $m("#dlMsg").textContent = "Saved ✓ " + base + "." + f;
  });
}

/* ---------- shop chrome: nav cart + corner points ---------- */
if (typeof loadShop === "function") loadShop().then(() => { try { paintCart(); } catch (e) {} }).catch(() => {});
ready();
})();
