/* COREKULT shop core: data, cart, 3 for 2, cart dropdown, free samples, sound previews with waveforms.
   Used by the shop page, pack pages and the checkout page. */
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const abs = (u) => (!u || /^(https?:|data:|\/)/.test(u) ? u : "/" + u);   // covers/audio work from /pack/... too
const PLAY = '<svg viewBox="0 0 10 10"><path d="M1 0l9 5-9 5z"/></svg>';
const STOP = '<svg viewBox="0 0 10 10"><path d="M0 0h10v10H0z"/></svg>';
let WORLDS = [], PRODUCTS = [], CUR = "EUR";            // CUR = the currency the buyer pays in (EUR or USD)
const money = (n) => new Intl.NumberFormat("en-IE", { style: "currency", currency: CUR, currencyDisplay: "narrowSymbol", minimumFractionDigits: n % 1 ? 2 : 0 }).format(n);
/* display currency: the buyer can pick any; checkout still charges in CUR */
let FX = { EUR: 1, USD: 1.08 }, DISP = "";
try { DISP = localStorage.getItem("ck-cur") || ""; } catch (e) {}
const disp = () => (DISP && FX[DISP] ? DISP : CUR);
const conv = (n) => n * (FX[disp()] || 1) / (FX[CUR] || 1);
function fmtIn(v, c, dec) {
  if (c === "EUR" || c === "USD") return new Intl.NumberFormat("en-IE", { style: "currency", currency: c, currencyDisplay: "narrowSymbol", minimumFractionDigits: dec, maximumFractionDigits: dec }).format(v);
  return new Intl.NumberFormat("en-IE", { minimumFractionDigits: dec, maximumFractionDigits: dec }).format(v) + " " + c;
}
/* price as shown on the site: in the picked currency, marked ≈ when it is a conversion */
const show = (n) => (disp() === CUR ? money(n) : "≈ " + fmtIn(conv(n), disp(), conv(n) >= 100 || !(conv(n) % 1) ? 0 : 2));
const soundCount = (p) => { const m = String(p.count || "").match(/(\d+)/); return Math.max(1, m ? +m[1] : (p.sounds || []).length); };
const perSound = (p) => { const v = p.price / soundCount(p), c = disp(), x = c === CUR ? v : conv(v); return `${c === CUR ? "" : "≈ "}${fmtIn(x, c, x < 10 ? 2 : 0)} per sound`; };
const CURS = ["EUR", "USD", "GBP", "SEK", "NOK", "DKK", "CHF", "PLN", "CZK", "HUF", "RON", "ISK", "TRY", "CAD", "AUD", "NZD", "JPY", "KRW", "CNY", "HKD", "SGD", "INR", "IDR", "MYR", "PHP", "THB", "BRL", "MXN", "ZAR", "ILS"];
function curUI() {
  const nav = $("nav.top .wrap"); if (!nav) return;
  let w = $("#curW");
  if (!w) {
    w = document.createElement("div"); w.className = "curw"; w.id = "curW";
    const cartw = $(".cartw", nav); cartw ? nav.insertBefore(w, cartw) : nav.insertBefore(w, nav.lastElementChild);
  }
  const list = CURS.filter((c) => FX[c]);
  w.innerHTML = `<button class="nl curb" id="curBtn" aria-label="Currency">${disp()}<svg viewBox="0 0 10 6"><path d="M0 0l5 6 5-6z"/></svg></button>
    <div class="curdd" id="curDd" hidden><div class="curg">${list.map((c) => `<button data-cur="${c}" class="${c === disp() ? "on" : ""}">${c}${c === CUR ? "<i></i>" : ""}</button>`).join("")}</div>
    <small>You pay in ${CUR}</small></div>`;
}
function setCur(c) { DISP = c === CUR ? "" : c; try { DISP ? localStorage.setItem("ck-cur", DISP) : localStorage.removeItem("ck-cur"); } catch (e) {} curUI(); document.dispatchEvent(new Event("ck-cur")); }
const byId = (id) => PRODUCTS.find((p) => p.id === id);
const DRAFT = new URLSearchParams(location.search).has("draft");
const QS = DRAFT ? "?draft=1" : "";
const packUrl = (id) => "/pack/" + encodeURIComponent(id) + QS;

/* ---------- cart (kept in this browser) ---------- */
let cart = [];
try { cart = JSON.parse(localStorage.getItem("ck-cart") || "[]"); } catch (e) { cart = []; }
const saveCart = () => { try { localStorage.setItem("ck-cart", JSON.stringify(cart)); } catch (e) {} };
const inCart = (id) => cart.includes(id);
const subtotal = () => cart.reduce((s, id) => s + (byId(id) ? byId(id).price : 0), 0);
/* 3 for 2: in every group of 3 packs (priced high to low) the cheapest one is free */
/* loyalty: 5 paid packs = 1 free pick. A free pick takes the priciest pack and sits outside 3 for 2, so they never stack */
const LOY_N = 5;
let LOY = { paid: 0, picks: 0 }, usePick = true;
const pickId = () => (LOY.picks > 0 && usePick && cart.length ? cart.filter(byId).slice().sort((a, b) => byId(b).price - byId(a).price)[0] : null);
const dealCart = () => { const k = pickId(); return cart.filter((id) => byId(id) && id !== k); };
function freeIds() { const ids = dealCart().sort((a, b) => byId(b).price - byId(a).price); return ids.filter((_, i) => i % 3 === 2); }
const dealOff = () => freeIds().reduce((s, id) => s + byId(id).price, 0);
const pickOff = () => (pickId() ? byId(pickId()).price : 0);
const total = () => subtotal() - dealOff() - pickOff();
const paidCount = () => dealCart().length - freeIds().length;
const dealStep = () => { const n = dealCart().length; return n && n % 3 === 0 ? 3 : n % 3; };
function offerHTML() {
  const k = dealStep();
  const msg = cart.length && k === 3 ? "Unlocked · one pack free" : `Add ${3 - k} more · one free`;
  return `<big>3=2</big><b>${msg}</b><span class="dots">${[0, 1, 2].map((i) => `<i class="${i < k ? "on" : ""}"></i>`).join("")}</span>`;
}
/* what a pack includes: "ARP · LEAD · PAD · BASS" from its preview names */
function kinds(p) {
  const k = [];
  (p.sounds || []).forEach((s) => { const w = String(s.name).split(/\s+/)[0].toUpperCase(); if (w && !/^\d+$/.test(w) && !k.includes(w)) k.push(w); });
  return k.join(" · ");
}
function sounds(p, max) {
  return (max ? p.sounds.slice(0, max) : p.sounds).map((s) => { if (s.w && !peaks.has(abs(s.file))) peaks.set(abs(s.file), s.w); return `<button data-src="${esc(abs(s.file))}"><span class="pl">${PLAY}</span><span class="nm">${esc(s.name)}</span><span class="mt">${esc(s.meta)}</span><canvas class="wf"></canvas></button>`; }).join("");
}
/* one pack as a row that drops down to show + play its samples (cart dropdown and checkout) */
const openRows = new Set();
function packRow(p, mode) {
  const free = freeIds().includes(p.id), open = openRows.has(p.id);
  return `<div class="ck${mode === "add" ? " add" : ""}${open ? " open" : ""}" data-id="${p.id}">
    <div class="ckh" data-tg="${p.id}"><img src="${esc(abs(p.cover))}" alt="">
      <div class="cit"><b>${esc(p.name)}<span class="chev">▾</span></b><small>${esc(p.sub)} · ${esc(p.count)}</small><em>${esc(kinds(p))}</em></div>
      <div class="pr">${free || p.id === pickId() ? `<span class="was">${show(p.price)}</span><span class="fr">${free ? "FREE" : "FREE PICK"}</span>` : show(p.price)}</div>
      ${mode === "add" ? `<button class="plus" data-add="${p.id}" aria-label="Add">+</button>` : `<button class="x" data-rm="${p.id}" aria-label="Remove">×</button>`}
    </div>
    <div class="ckb"${open ? "" : " hidden"}><p class="pi">${esc(p.blurb)}</p><div class="pv">${sounds(p)}</div></div></div>`;
}
function toggleRow(head) {
  const id = head.dataset.tg, box = head.parentNode;
  openRows.has(id) ? openRows.delete(id) : openRows.add(id);
  box.classList.toggle("open", openRows.has(id)); $(".ckb", box).hidden = !openRows.has(id);
  watchWaves(box);
}

/* ---------- cart dropdown under the cart icon (shop + pack pages) ---------- */
function addToCart(id) { if (!inCart(id)) cart.push(id); saveCart(); paintCart(); openCart(); }
function removeFromCart(id) { cart = cart.filter((x) => x !== id); saveCart(); paintCart(); }
function openCart() { if (!$("#cartDd")) return; paintCart(); $("#cartDd").hidden = false; $("#cartBtn").classList.add("open"); }
function closeCart() { if (!$("#cartDd")) return; $("#cartDd").hidden = true; $("#cartBtn").classList.remove("open"); }
function paintCart() {
  if (!$("#cartN")) return;
  $("#cartN").textContent = cart.length; $("#cartN").hidden = !cart.length;
  document.querySelectorAll("[data-add]:not(.plus)").forEach((b) => {
    const on = inCart(b.dataset.add);
    b.textContent = on ? "In cart" : "Add to cart";
    b.classList.toggle("acid", !on); b.classList.toggle("ghost", on);
  });
  if (!$("#cartDd")) return;
  const items = cart.map(byId), off = dealOff();
  const rest = PRODUCTS.filter((p) => !inCart(p.id));
  $("#cartDd").innerHTML = !items.length ? `<div class="empty">Your cart is empty.</div>` : `
    <div class="cdl">${items.map((p) => packRow(p, "in")).join("")}</div>
    <div class="offer sm">${offerHTML()}</div>
    ${rest.length ? `<div class="cdl">${rest.map((p) => packRow(p, "add")).join("")}</div>` : ""}
    <div class="cft">${off ? `<div class="row off"><span>3 for 2</span><span>−${show(off)}</span></div>` : ""}${pickOff() ? `<div class="row off"><span>Free pick</span><span>−${show(pickOff())}</span></div>` : ""}<div class="row tot"><span>Total</span><span>${show(total())}</span></div>
    <a class="btn acid wide" href="/checkout${QS}">Checkout</a></div>`;
  watchWaves($("#cartDd"));
}

/* ---------- free samples drawer ---------- */
function openDrawer(view) {
  document.querySelectorAll(".dv").forEach((v) => v.hidden = v.dataset.v !== view);
  $("#drawer").classList.add("open"); $("#scrim").hidden = false; document.body.classList.add("lock");
}
function closeDrawer() { if (!$("#drawer")) return; $("#drawer").classList.remove("open"); $("#scrim").hidden = true; document.body.classList.remove("lock"); }
function showFree(id) {
  const p = byId(id);
  $("#frName").textContent = p.name;
  $("#frCover").src = abs(p.cover);
  $("#frList").innerHTML = p.sounds.slice(0, p.freeCount || 5).map((s) => `<a class="li dl" href="${esc(abs(s.file))}" download><span class="pl">↓</span><span>${esc(s.name)}</span><small>${esc(s.meta || "mp3")}</small></a>`).join("");
  $("#frList").hidden = true; $("#frForm").hidden = false; try { $("#frEmail").value = localStorage.getItem("ck-email") || ""; } catch (e) { $("#frEmail").value = ""; }
  $("#frGo").onclick = () => {
    if (p.payhipFree && window.Payhip) { window.open("https://payhip.com/b/" + p.payhipFree, "_blank"); return; }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test($("#frEmail").value.trim())) { $("#frEmail").focus(); $("#frEmail").classList.add("bad"); return; }
    const em = $("#frEmail").value.trim();
    fetch("/api/free", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ email: em, pack: p.id }) }).catch(() => {});
    try { localStorage.setItem("ck-email", em); } catch (e) {}
    $("#frEmail").classList.remove("bad"); $("#frForm").hidden = true; $("#frList").hidden = false;
  };
  closeCart(); openDrawer("free");
}
/* clicks shared by the shop and pack pages */
function shopClick(e) {
  const t = e.target;
  if (t.closest(".pv button")) return true;
  const add = t.closest("[data-add]"); if (add) { inCart(add.dataset.add) ? openCart() : addToCart(add.dataset.add); return true; }
  const rm = t.closest("[data-rm]"); if (rm) { removeFromCart(rm.dataset.rm); return true; }
  const tg = t.closest("[data-tg]"); if (tg) { toggleRow(tg); return true; }
  if (t.closest("#cartBtn")) { $("#cartDd").hidden ? openCart() : closeCart(); return true; }
  if (t.closest("#curBtn")) { $("#curDd").hidden = !$("#curDd").hidden; return true; }
  const cu = t.closest("[data-cur]"); if (cu) { setCur(cu.dataset.cur); return true; }
  if ($("#curDd") && !t.closest("#curW")) $("#curDd").hidden = true;
  const fr = t.closest("[data-free]"); if (fr) { showFree(fr.dataset.free); return true; }
  if (t.closest("#scrim") || t.closest("[data-close]")) { closeDrawer(); return true; }
  if ($("#cartDd") && !t.closest("#cartDd")) closeCart();
  return false;
}
document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closeDrawer(); closeCart(); } });

/* ---------- data ---------- */
function loadShop() {
  let src;
  if (DRAFT) { try { const d = JSON.parse(localStorage.getItem("ck-draft") || "null"); if (d) src = Promise.resolve(d); } catch (e) {} }
  if (!src) src = fetch("/api/products", { cache: "no-store" }).then((r) => { if (!r.ok) throw 0; return r.json(); })
    .catch(() => fetch("/products.json?v=" + Date.now()).then((r) => r.json()));
  const fx = fetch("/api/fx").then((r) => r.json()).then((d) => { if (d && d.rates) FX = d.rates; }).catch(() => {});
  return Promise.all([src, fx]).then(([d]) => {
    let force = ""; try { force = new URLSearchParams(location.search).get("pay") || ""; } catch (e) {}
    CUR = /^(EUR|USD)$/.test(force) ? force : d.pay || d.currency || "EUR";
    PRODUCTS = d.products.filter((p) => (p.status || "live") === "live").map((p) => ({ ...p, priceEur: p.price, price: CUR === "USD" ? Number(p.priceUsd || p.price) : p.price, sounds: (p.sounds || []).filter((s) => !s.hidden) }));
    WORLDS = d.worlds.filter((w) => PRODUCTS.some((p) => p.world === w.id));
    cart = cart.filter(byId); saveCart(); curUI();
    if (DRAFT) { const b = document.createElement("div"); b.textContent = "PREVIEW · NOT LIVE"; b.style.cssText = "position:fixed;left:0;bottom:0;z-index:90;background:#8b6cf6;color:#0b0a0e;font:800 10px/1 Inter,sans-serif;letter-spacing:.2em;padding:9px 10px"; document.body.appendChild(b); }
    if (PRODUCTS.some((p) => p.payhip || p.payhipFree)) { const s = document.createElement("script"); s.src = "https://payhip.com/payhip.js"; document.body.appendChild(s); }
    return loadLoyalty().catch(() => {});
  });
}

/* ---------- waveforms (same look as the KILLTOY review pages) ---------- */
const BARS = 96, peaks = new Map(), pending = new Map();
let actx = null;
function getPeaks(src) {
  if (peaks.has(src)) return Promise.resolve(peaks.get(src));
  try { const c = JSON.parse(localStorage.getItem("ck-wf:" + src) || "null"); if (c) { peaks.set(src, c); return Promise.resolve(c); } } catch (e) {}
  if (pending.has(src)) return pending.get(src);
  const job = fetch(src).then((r) => r.arrayBuffer()).then((buf) => {
    actx = actx || new (window.OfflineAudioContext || window.webkitOfflineAudioContext)(1, 1, 44100);
    return new Promise((ok, bad) => actx.decodeAudioData(buf, ok, bad));
  }).then((ab) => {
    const d = ab.getChannelData(0), step = Math.floor(d.length / BARS) || 1, out = [];
    for (let i = 0; i < BARS; i++) { let m = 0; for (let j = i * step, e = Math.min(d.length, j + step); j < e; j += 4) { const v = Math.abs(d[j]); if (v > m) m = v; } out.push(m); }
    const top = Math.max(...out) || 1, w = out.map((v) => Math.round((v / top) * 100) / 100);
    peaks.set(src, w); try { localStorage.setItem("ck-wf:" + src, JSON.stringify(w)); } catch (e) {}
    return w;
  }).catch(() => null);
  pending.set(src, job); return job;
}
function drawWave(btn, ph) {
  const cv = btn.querySelector("canvas.wf"); if (!cv) return;
  const w = peaks.get(btn.dataset.src), r = cv.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
  const W = Math.max(20, Math.round(r.width)), H = Math.round(r.height); if (!H) return;
  if (cv.width !== W * dpr || cv.height !== H * dpr) { cv.width = W * dpr; cv.height = H * dpr; }
  const g = cv.getContext("2d"); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
  const on = btn === curBtn, n = w ? w.length : BARS, bw = W / n;
  for (let i = 0; i < n; i++) {
    const v = w ? Math.max(0.04, w[i]) : 0.04, h = v * (H - 2), past = on && ph != null && i / n <= ph;
    g.fillStyle = past ? "#e4ff3a" : on ? "#b8a4ff" : "#8b6cf6"; g.globalAlpha = past ? 1 : 0.85;
    g.fillRect(i * bw + 0.5, (H - h) / 2, Math.max(1, bw - 1.2), h);
  }
  g.globalAlpha = 1;
}
const waveIO = "IntersectionObserver" in window ? new IntersectionObserver((es) => es.forEach((e) => {
  if (!e.isIntersecting) return; waveIO.unobserve(e.target);
  const b = e.target; drawWave(b); getPeaks(b.dataset.src).then(() => drawWave(b));
}), { rootMargin: "200px" }) : null;
function watchWaves(root = document) {
  root.querySelectorAll(".pv button").forEach((b) => { if (waveIO) waveIO.observe(b); else getPeaks(b.dataset.src).then(() => drawWave(b)); });
}
let rsz; addEventListener("resize", () => { clearTimeout(rsz); rsz = setTimeout(() => document.querySelectorAll(".pv button").forEach((b) => peaks.has(b.dataset.src) && drawWave(b, b === curBtn ? audio.currentTime / (audio.duration || 1) : null)), 120); });

/* ---------- previews: one sound at a time, tap the wave to jump ---------- */
const audio = new Audio(); audio.preload = "none"; let curBtn = null;
function stopCur() { const b = curBtn; if (b) { b.classList.remove("on"); $(".pl", b).innerHTML = PLAY; } curBtn = null; if (b) drawWave(b); }
function tick() { if (!curBtn) return; drawWave(curBtn, audio.duration ? audio.currentTime / audio.duration : 0); requestAnimationFrame(tick); }
document.addEventListener("click", (e) => {
  const b = e.target.closest(".pv button"); if (!b) return;
  const cv = e.target.closest("canvas.wf");
  const at = cv ? Math.min(0.99, Math.max(0, (e.clientX - cv.getBoundingClientRect().left) / cv.getBoundingClientRect().width)) : null;
  if (curBtn === b) {
    if (at != null && audio.duration) { audio.currentTime = at * audio.duration; return; }
    audio.pause(); stopCur(); return;
  }
  stopCur(); curBtn = b; b.classList.add("on"); $(".pl", b).innerHTML = STOP;
  audio.src = b.dataset.src; audio.currentTime = 0;
  if (at != null) audio.addEventListener("loadedmetadata", () => { if (curBtn === b) audio.currentTime = at * audio.duration; }, { once: true });
  audio.play().then(() => requestAnimationFrame(tick)).catch(stopCur);
  getPeaks(b.dataset.src).then(() => drawWave(b, 0));
});
audio.addEventListener("ended", stopCur);

/* plastic covers lean toward the mouse (desktop) */
if (matchMedia("(hover:hover)").matches) {
  document.addEventListener("pointermove", (e) => {
    const q = e.target.closest && e.target.closest(".pq");
    document.querySelectorAll(".pq.tl").forEach((x) => { if (x !== q) { x.classList.remove("tl"); x.style.transform = ""; x.firstElementChild.nextElementSibling.style.backgroundPosition = ""; } });
    if (!q) return;
    const r = q.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
    q.classList.add("tl");
    q.style.transform = `perspective(800px) rotateX(${(-y * 10).toFixed(2)}deg) rotateY(${(x * 12).toFixed(2)}deg) translateY(-3px)`;
    q.querySelector(".gl").style.backgroundPosition = `${(50 + x * 80).toFixed(1)}% 50%, 0 0`;
  }, { passive: true });
}

/* ---------- loyalty meter (corner) ---------- */
const myEmail = () => { try { return localStorage.getItem("ck-email") || ""; } catch (e) { return ""; } };
const demoLoy = () => { try { return JSON.parse(localStorage.getItem("ck-loy-demo") || '{"paid":0,"used":0}'); } catch (e) { return { paid: 0, used: 0 }; } };
function loadLoyalty() {
  const em = myEmail(), d = demoLoy();
  const base = em ? fetch("/api/loyalty?email=" + encodeURIComponent(em)).then((r) => r.json()).catch(() => ({ paid: 0, used: 0 })) : Promise.resolve({ paid: 0, used: 0 });
  return base.then((b) => { const paid = (b.paid || 0) + d.paid, used = (b.used || 0) + d.used; LOY = { paid, picks: Math.floor(paid / LOY_N) - used }; paintLoy(); return LOY; });
}
function loyHTML(paid, picks) {
  const k = paid % LOY_N, left = LOY_N - k;
  return `<div class="loyh"><b>Loyalty</b><span>${k * (100 / LOY_N)}%</span></div>
    <div class="loyb">${Array.from({ length: LOY_N }, (_, i) => `<i class="${i < k ? "on" : ""}"></i>`).join("")}</div>
    <div class="loyt">${picks > 0 ? `<em>★ ${picks} free pick${picks > 1 ? "s" : ""}</em> · ` : ""}${left === 1 ? "1 more pack → free pack" : left + " more packs → free pack"}</div>`;
}
function paintLoy() {
  if (!myEmail() && !LOY.paid) return;
  let el = $("#loy"); if (!el) { el = document.createElement("div"); el.id = "loy"; el.className = "loy"; document.body.appendChild(el); }
  el.innerHTML = loyHTML(LOY.paid, LOY.picks);
}
/* little game sound: coin blips, a chord when a free pack is earned */
function blip(i, big) {
  try {
    const C = blip.c || (blip.c = new (window.AudioContext || window.webkitAudioContext)()), t = C.currentTime;
    const notes = big ? [523, 659, 784, 1047] : [660 + i * 110, 990 + i * 110];
    notes.forEach((f, j) => { const o = C.createOscillator(), g = C.createGain(); o.type = "square"; o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t + j * 0.07); g.gain.exponentialRampToValueAtTime(0.06, t + j * 0.07 + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + j * 0.07 + (big ? 0.35 : 0.12));
      o.connect(g).connect(C.destination); o.start(t + j * 0.07); o.stop(t + j * 0.07 + 0.4); });
  } catch (e) {}
}
/* fill the meter one block at a time after a purchase */
function loyGain(n, quiet) {
  const start = LOY.paid; LOY.paid += n;
  let el = $("#loy"); if (!el) { el = document.createElement("div"); el.id = "loy"; el.className = "loy"; document.body.appendChild(el); }
  el.classList.add("big");
  let step = 0, picks = LOY.picks;
  el.innerHTML = loyHTML(start, picks);
  const tick = () => {
    if (step >= n) { LOY.picks = picks; setTimeout(() => { el.classList.remove("big"); paintLoy(); }, 1600); return; }
    step++; const p = start + step, done = p % LOY_N === 0;
    if (done) picks++;
    el.innerHTML = loyHTML(done ? p - 1 : p, picks - (done ? 1 : 0));
    if (done) { el.querySelectorAll(".loyb i").forEach((x) => x.classList.add("on")); el.querySelector(".loyh span").textContent = "100%"; el.querySelector(".loyt").innerHTML = "<em>★ +1 free pick</em> · use it on any pack"; }
    el.querySelector(`.loyb i:nth-child(${done ? LOY_N : p % LOY_N})`).classList.add("pop");
    if (!quiet) blip(step, done);
    if (done) { el.classList.add("win"); el.insertAdjacentHTML("beforeend", `<div class="loyw">Free pack earned</div>`); setTimeout(() => el.classList.remove("win"), 1400); setTimeout(tick, 1500); }
    else setTimeout(tick, 420);
  };
  setTimeout(tick, 500);
}
