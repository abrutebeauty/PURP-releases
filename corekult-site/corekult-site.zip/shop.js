/* COREKULT shop core: data, cart, 3 for 2, sound previews. Used by the shop page and the checkout page. */
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const PLAY = '<svg viewBox="0 0 10 10"><path d="M1 0l9 5-9 5z"/></svg>';
const STOP = '<svg viewBox="0 0 10 10"><path d="M0 0h10v10H0z"/></svg>';
let WORLDS = [], PRODUCTS = [], CUR = "EUR";
const money = (n) => new Intl.NumberFormat("en-IE", { style: "currency", currency: CUR, minimumFractionDigits: n % 1 ? 2 : 0 }).format(n);
const byId = (id) => PRODUCTS.find((p) => p.id === id);

/* ---------- cart (kept in this browser) ---------- */
let cart = [];
try { cart = JSON.parse(localStorage.getItem("ck-cart") || "[]"); } catch (e) { cart = []; }
const saveCart = () => { try { localStorage.setItem("ck-cart", JSON.stringify(cart)); } catch (e) {} };
const inCart = (id) => cart.includes(id);
const subtotal = () => cart.reduce((s, id) => s + (byId(id) ? byId(id).price : 0), 0);
/* 3 for 2: in every group of 3 packs (priced high to low) the cheapest one is free */
function freeIds() { const ids = cart.filter(byId).slice().sort((a, b) => byId(b).price - byId(a).price); return ids.filter((_, i) => i % 3 === 2); }
const dealOff = () => freeIds().reduce((s, id) => s + byId(id).price, 0);
const total = () => subtotal() - dealOff();
/* how far into the current group of 3 the cart is: 0..3 filled */
const dealStep = () => { const n = cart.length; return n && n % 3 === 0 ? 3 : n % 3; };
function offerHTML() {
  const k = dealStep();
  const msg = cart.length && k === 3 ? "Unlocked · cheapest pack free" : `Add ${3 - k} more · cheapest free`;
  return `<big>3=2</big><b>${msg}</b><span class="dots">${[0, 1, 2].map((i) => `<i class="${i < k ? "on" : ""}"></i>`).join("")}</span>`;
}
/* what a pack includes: "ARP · LEAD · PAD · BASS" from its preview names */
function kinds(p) {
  const k = [];
  (p.sounds || []).forEach((s) => { const w = String(s.name).split(/\s+/)[0].toUpperCase(); if (w && !/^\d+$/.test(w) && !k.includes(w)) k.push(w); });
  return k.join(" · ");
}
function sounds(p, max) {
  return (max ? p.sounds.slice(0, max) : p.sounds).map((s) => `<button data-src="${esc(s.file)}"><span class="pl">${PLAY}</span><span class="nm">${esc(s.name)}</span><span class="mt">${esc(s.meta)}</span></button>`).join("");
}

/* ---------- data ---------- */
const DRAFT = new URLSearchParams(location.search).has("draft");
function loadShop() {
  let src;
  if (DRAFT) { try { const d = JSON.parse(localStorage.getItem("ck-draft") || "null"); if (d) src = Promise.resolve(d); } catch (e) {} }
  if (!src) src = fetch("/api/products", { cache: "no-store" }).then((r) => { if (!r.ok) throw 0; return r.json(); })
    .catch(() => fetch("/products.json?v=" + Date.now()).then((r) => r.json()));
  return src.then((d) => {
    CUR = d.currency || "EUR";
    PRODUCTS = d.products.filter((p) => (p.status || "live") === "live").map((p) => ({ ...p, sounds: (p.sounds || []).filter((s) => !s.hidden) }));
    WORLDS = d.worlds.filter((w) => PRODUCTS.some((p) => p.world === w.id));
    cart = cart.filter(byId); saveCart();
    if (DRAFT) { const b = document.createElement("div"); b.textContent = "PREVIEW · NOT LIVE"; b.style.cssText = "position:fixed;left:0;bottom:0;z-index:90;background:#8b6cf6;color:#0b0a0e;font:800 10px/1 Inter,sans-serif;letter-spacing:.2em;padding:9px 10px"; document.body.appendChild(b); }
    if (PRODUCTS.some((p) => p.payhip || p.payhipFree)) { const s = document.createElement("script"); s.src = "https://payhip.com/payhip.js"; document.body.appendChild(s); }
  });
}

/* ---------- previews: one sound at a time ---------- */
const audio = new Audio(); audio.preload = "none"; let curBtn = null;
function stopCur() { if (curBtn) { curBtn.classList.remove("on"); $(".pl", curBtn).innerHTML = PLAY; } curBtn = null; }
document.addEventListener("click", (e) => {
  const b = e.target.closest(".pv button"); if (!b) return;
  if (curBtn === b) { audio.pause(); stopCur(); return; }
  stopCur(); curBtn = b; b.classList.add("on"); $(".pl", b).innerHTML = STOP;
  audio.src = b.dataset.src; audio.currentTime = 0; audio.play().catch(stopCur);
});
audio.addEventListener("ended", stopCur);
