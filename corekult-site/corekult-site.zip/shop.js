/* COREKULT shop core: data, cart, 3 for 2, cart dropdown, free samples, sound previews with waveforms.
   Used by the shop page, pack pages and the checkout page. */
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const abs = (u) => (!u || /^(https?:|data:|\/)/.test(u) ? u : "/" + u);   // covers/audio work from /pack/... too
const PLAY = '<svg viewBox="0 0 10 10"><path d="M1 0l9 5-9 5z"/></svg>';
const STOP = '<svg viewBox="0 0 10 10"><path d="M0 0h10v10H0z"/></svg>';
let WORLDS = [], PRODUCTS = [], CUR = "EUR", DEALS = { cards: [] };            // CUR = the currency the buyer pays in (EUR or USD)
const money = (n) => new Intl.NumberFormat("en-IE", { style: "currency", currency: CUR, currencyDisplay: "narrowSymbol", minimumFractionDigits: n % 1 ? 2 : 0 }).format(n);
/* display currency: the buyer can pick any; checkout still charges in CUR */
let FX = { EUR: 1, USD: 1.08 }, DISP = "";
try { DISP = localStorage.getItem("ck-cur") || ""; } catch (e) {}
const disp = () => (DISP && FX[DISP] ? DISP : CUR);
const conv = (n) => n * (FX[disp()] || 1) / (FX[CUR] || 1);
function fmtIn(v, c, dec) {
  if (c === "EUR" || c === "USD") return new Intl.NumberFormat("en-IE", { style: "currency", currency: c, currencyDisplay: "narrowSymbol", minimumFractionDigits: dec, maximumFractionDigits: dec }).format(v);
  return new Intl.NumberFormat("en-IE", { minimumFractionDigits: dec, maximumFractionDigits: dec }).format(v) + " " + c;
}
/* price as shown on the site: in the picked currency, marked ≈ when it is a conversion */
const show = (n) => (disp() === CUR ? money(n) : "≈ " + fmtIn(conv(n), disp(), conv(n) >= 100 || !(conv(n) % 1) ? 0 : 2));
const soundCount = (p) => { const m = String(p.count || "").match(/(\d+)/); return Math.max(1, m ? +m[1] : (p.sounds || []).length); };
const perSound = (p) => { const v = p.price / soundCount(p), c = disp(), x = c === CUR ? v : conv(v); return `${c === CUR ? "" : "≈ "}${fmtIn(x, c, x < 10 ? 2 : 0)} per sound`; };
const CURS = ["EUR", "USD", "GBP", "SEK", "NOK", "DKK", "CHF", "PLN", "CZK", "HUF", "RON", "ISK", "TRY", "CAD", "AUD", "NZD", "JPY", "KRW", "CNY", "HKD", "SGD", "INR", "IDR", "MYR", "PHP", "THB", "BRL", "MXN", "ZAR", "ILS"];
function curUI() {
  const nav = $("nav.top .wrap"); if (!nav) return;
  let w = $("#curW");
  if (!w) {
    w = document.createElement("div"); w.className = "curw"; w.id = "curW";
    const cartw = $(".cartw", nav); cartw ? nav.insertBefore(w, cartw) : nav.insertBefore(w, nav.lastElementChild);
  }
  const list = CURS.filter((c) => FX[c]);
  w.innerHTML = `<button class="nl curb" id="curBtn" aria-label="Currency">${disp()}<svg viewBox="0 0 10 6"><path d="M0 0l5 6 5-6z"/></svg></button>
    <div class="curdd" id="curDd" hidden><div class="curg">${list.map((c) => `<button data-cur="${c}" class="${c === disp() ? "on" : ""}">${c}${c === CUR ? "<i></i>" : ""}</button>`).join("")}</div>
    <small>You pay in ${CUR}</small></div>`;
}
function setCur(c) { DISP = c === CUR ? "" : c; try { DISP ? localStorage.setItem("ck-cur", DISP) : localStorage.removeItem("ck-cur"); } catch (e) {} curUI(); document.dispatchEvent(new Event("ck-cur")); }
const byId = (id) => PRODUCTS.find((p) => p.id === id);
const DRAFT = new URLSearchParams(location.search).has("draft");
const QS = DRAFT ? "?draft=1" : "";
const packUrl = (id) => "/pack/" + encodeURIComponent(id) + QS;

/* ---------- cart (kept in this browser) ---------- */
let cart = [];
try { cart = JSON.parse(localStorage.getItem("ck-cart") || "[]"); } catch (e) { cart = []; }
const saveCart = () => { try { localStorage.setItem("ck-cart", JSON.stringify(cart)); } catch (e) {} };
const inCart = (id) => cart.includes(id);
const subtotal = () => cart.reduce((s, id) => s + (byId(id) ? byId(id).price : 0), 0);
/* 3 for 2: in every group of 3 packs (priced high to low) the cheapest one is free */
/* loyalty: 5 paid packs = 1 free pick. A free pick takes the priciest pack and sits outside 3 for 2, so they never stack */
const LOY_N = 5;
let LOY = { paid: 0, picks: 0 }, usePick = true;
const pickId = () => (LOY.picks > 0 && usePick && cart.length ? cart.filter(byId).slice().sort((a, b) => byId(b).price - byId(a).price)[0] : null);
const dealCart = () => { const k = pickId(); return cart.filter((id) => byId(id) && id !== k); };
function freeIds3() { const ids = dealCart().sort((a, b) => byId(b).price - byId(a).price); return ids.filter((_, i) => i % 3 === 2); }
const off3 = () => freeIds3().reduce((s, id) => s + byId(id).price, 0);
/* deal card: saved on this browser after a claim; used instead of 3 for 2 only when it saves more */
let CARD = null; try { CARD = JSON.parse(localStorage.getItem("ck-card") || "null"); } catch (e) {}
const cardDef = () => (CARD && (DEALS.cards || []).find((c) => c.id === CARD.tier)) || null;
const cardLive = () => !!(CARD && !CARD.used && CARD.exp > Date.now() && cardDef());
function cardOff() {
  if (!cardLive()) return 0;
  const c = cardDef(), ids = dealCart().sort((a, b) => byId(b).price - byId(a).price), pr = (id) => byId(id).price;
  if (c.kind === "pct") return ids.length ? Math.round(pr(ids[0]) * c.pct) / 100 : 0;
  if (c.kind === "b1g1") return ids.length >= 2 ? pr(ids[1]) : 0;
  if (c.kind === "bundle3") return ids.length >= 3 ? Math.round((pr(ids[0]) + pr(ids[1]) + pr(ids[2])) * c.pct) / 100 : 0;
  return 0;
}
const useCard = () => cardOff() > off3();
function freeIds() { return useCard() ? [] : freeIds3(); }
const dealOff = () => (useCard() ? 0 : off3());
const pickOff = () => (pickId() ? byId(pickId()).price : 0);
const total = () => Math.round((subtotal() - dealOff() - (useCard() ? cardOff() : 0) - pickOff()) * 100) / 100;
const paidCount = () => dealCart().length - freeIds().length;
const dealStep = () => { const n = dealCart().length; return n && n % 3 === 0 ? 3 : n % 3; };
function offerHTML() {
  const k = dealStep();
  const msg = cart.length && k === 3 ? "Unlocked · one pack free" : `Add ${3 - k} more · one free`;
  return `<big>3=2</big><b>${msg}</b><span class="dots">${[0, 1, 2].map((i) => `<i class="${i < k ? "on" : ""}"></i>`).join("")}</span>`;
}
/* what a pack includes: "ARP · LEAD · PAD · BASS" from its preview names */
function kinds(p) {
  const k = [];
  (p.sounds || []).forEach((s) => { const w = String(s.name).split(/\s+/)[0].toUpperCase(); if (w && !/^\d+$/.test(w) && !k.includes(w)) k.push(w); });
  return k.join(" · ");
}
function sounds(p, max) {
  return (max ? p.sounds.slice(0, max) : p.sounds).map((s) => { if (s.w && !peaks.has(abs(s.file))) peaks.set(abs(s.file), s.w); return `<button data-src="${esc(abs(s.file))}"><span class="pl">${PLAY}</span><span class="nm">${esc(s.name)}</span><span class="mt">${esc(s.meta)}</span><canvas class="wf"></canvas></button>`; }).join("");
}
/* one pack as a row that drops down to show + play its samples (cart dropdown and checkout) */
const openRows = new Set();
function packRow(p, mode) {
  const free = freeIds().includes(p.id), open = openRows.has(p.id);
  return `<div class="ck${mode === "add" ? " add" : ""}${open ? " open" : ""}" data-id="${p.id}">
    <div class="ckh" data-tg="${p.id}"><img src="${esc(abs(p.cover))}" alt="">
      <div class="cit"><b>${esc(p.name)}<span class="chev">▾</span></b><small>${esc(p.sub)} · ${esc(p.count)}</small><em>${esc(kinds(p))}</em></div>
      <div class="pr">${free || p.id === pickId() ? `<span class="was">${show(p.price)}</span><span class="fr">${free ? "FREE" : "FREE PICK"}</span>` : show(p.price)}</div>
      ${mode === "add" ? `<button class="plus" data-add="${p.id}" aria-label="Add">+</button>` : `<button class="x" data-rm="${p.id}" aria-label="Remove">×</button>`}
    </div>
    <div class="ckb"${open ? "" : " hidden"}><p class="pi">${esc(p.blurb)}</p><div class="pv">${sounds(p)}</div></div></div>`;
}
function toggleRow(head) {
  const id = head.dataset.tg, box = head.parentNode;
  openRows.has(id) ? openRows.delete(id) : openRows.add(id);
  box.classList.toggle("open", openRows.has(id)); $(".ckb", box).hidden = !openRows.has(id);
  watchWaves(box);
}

/* ---------- cart dropdown under the cart icon (shop + pack pages) ---------- */
function addToCart(id) { if (!inCart(id)) { cart.push(id); track("cart", id, location.pathname, byId(id) && byId(id).price); } saveCart(); paintCart(); openCart(); }
function removeFromCart(id) { cart = cart.filter((x) => x !== id); saveCart(); paintCart(); }
function openCart() { if (!$("#cartDd")) return; paintCart(); $("#cartDd").hidden = false; $("#cartBtn").classList.add("open"); }
function closeCart() { if (!$("#cartDd")) return; $("#cartDd").hidden = true; $("#cartBtn").classList.remove("open"); }
function paintCart() {
  if (!$("#cartN")) return;
  $("#cartN").textContent = cart.length; $("#cartN").hidden = !cart.length;
  document.querySelectorAll("[data-add]:not(.plus)").forEach((b) => {
    const on = inCart(b.dataset.add);
    b.textContent = on ? "In cart" : "Add to cart";
    b.classList.toggle("acid", !on); b.classList.toggle("ghost", on);
  });
  if (!$("#cartDd")) return;
  const items = cart.map(byId), off = dealOff();
  const rest = PRODUCTS.filter((p) => !inCart(p.id));
  $("#cartDd").innerHTML = !items.length ? `<div class="empty">Your cart is empty.</div>` : `
    <div class="cdl">${items.map((p) => packRow(p, "in")).join("")}</div>
    <div class="offer sm">${offerHTML()}</div>
    ${rest.length ? `<div class="cdl">${rest.map((p) => packRow(p, "add")).join("")}</div>` : ""}
    <div class="cft">${off ? `<div class="row off"><span>3 for 2</span><span>−${show(off)}</span></div>` : ""}${pickOff() ? `<div class="row off"><span>Free pick</span><span>−${show(pickOff())}</span></div>` : ""}${useCard() ? `<div class="row off"><span>★ ${esc(cardDef().name)} card</span><span>−${show(cardOff())}</span></div>` : ""}<div class="row tot"><span>Total</span><span>${show(total())}</span></div>
    <a class="btn acid wide" href="/checkout${QS}">Checkout</a></div>`;
  watchWaves($("#cartDd"));
}

/* ---------- free samples drawer ---------- */
function openDrawer(view) {
  document.querySelectorAll(".dv").forEach((v) => v.hidden = v.dataset.v !== view);
  $("#drawer").classList.add("open"); $("#scrim").hidden = false; document.body.classList.add("lock");
}
function closeDrawer() { if (!$("#drawer")) return; $("#drawer").classList.remove("open"); $("#scrim").hidden = true; document.body.classList.remove("lock"); }
function showFree(id) {
  const p = byId(id);
  $("#frName").textContent = p.name;
  $("#frCover").src = abs(p.cover);
  $("#frList").innerHTML = p.sounds.slice(0, p.freeCount || 5).map((s) => `<a class="li dl" href="${esc(abs(s.file))}" download><span class="pl">↓</span><span>${esc(s.name)}</span><small>${esc(s.meta || "mp3")}</small></a>`).join("");
  if ($("#frClaim")) $("#frClaim").hidden = true;
  $("#frList").hidden = true; $("#frForm").hidden = false; try { $("#frEmail").value = localStorage.getItem("ck-email") || ""; } catch (e) { $("#frEmail").value = ""; }
  $("#frGo").onclick = () => {
    if (p.payhipFree && window.Payhip) { window.open("https://payhip.com/b/" + p.payhipFree, "_blank"); return; }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test($("#frEmail").value.trim())) { $("#frEmail").focus(); $("#frEmail").classList.add("bad"); return; }
    const em = $("#frEmail").value.trim();
    try { localStorage.setItem("ck-email", em); } catch (e) {}
    fetch("/api/free", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ email: em, pack: p.id }) })
      .then((r) => r.json()).then((r) => { if (r.isNew && DEALS.signupBlocks) loyGain(DEALS.signupBlocks); else loadLoyalty(); }).catch(() => {});
    $("#frEmail").classList.remove("bad"); $("#frForm").hidden = true; $("#frList").hidden = false;
    if (DEALS.enabled !== false) claimBlock(em); track("free", p.id);
  };
  closeCart(); openDrawer("free");
}
/* clicks shared by the shop and pack pages */
function shopClick(e) {
  const t = e.target;
  if (t.closest(".pv button")) return true;
  const add = t.closest("[data-add]"); if (add) { inCart(add.dataset.add) ? openCart() : addToCart(add.dataset.add); return true; }
  const rm = t.closest("[data-rm]"); if (rm) { removeFromCart(rm.dataset.rm); return true; }
  const tg = t.closest("[data-tg]"); if (tg) { toggleRow(tg); return true; }
  if (t.closest("#cartBtn")) { $("#cartDd").hidden ? openCart() : closeCart(); return true; }
  if (t.closest("[data-mycard]")) { showCard(CARD, false); return true; }
  if (t.closest("#cardX") || t.closest("#cardLater")) { closeCard(); return true; }
  if (t.closest("#cardMute")) { setMute(!muted()); return true; }
  if (t.closest("#claimEdit")) { $("#frClaim").hidden = true; $("#frList").hidden = true; $("#frForm").hidden = false; $("#frEmail").focus(); return true; }
  if (t.closest("#claimGo")) { claim(); return true; }
  if (t.closest("#cMore")) { $("#cMoreTx").hidden = !$("#cMoreTx").hidden; return true; }
  if (t.closest("[data-cookies]")) { try { localStorage.removeItem("ck-consent"); } catch (er) {} consentBar(); return true; }
  if (t.closest("[data-consent]")) { const c = t.closest("[data-consent]").dataset.consent; if (c === "pick") setConsent($("#cStats").checked, $("#cStats").checked && $("#cRec").checked); else setConsent(c === "yes"); return true; }
  if (t.closest("#curBtn")) { $("#curDd").hidden = !$("#curDd").hidden; return true; }
  const cu = t.closest("[data-cur]"); if (cu) { setCur(cu.dataset.cur); return true; }
  if ($("#curDd") && !t.closest("#curW")) $("#curDd").hidden = true;
  const fr = t.closest("[data-free]"); if (fr) { showFree(fr.dataset.free); return true; }
  if (t.closest("#scrim") || t.closest("[data-close]")) { closeDrawer(); return true; }
  if ($("#cartDd") && !t.closest("#cartDd")) closeCart();
  return false;
}
document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closeDrawer(); closeCart(); } });

/* ---------- data ---------- */
function loadShop() {
  let src;
  if (DRAFT) { try { const d = JSON.parse(localStorage.getItem("ck-draft") || "null"); if (d) src = Promise.resolve(d); } catch (e) {} }
  if (!src) src = fetch("/api/products", { cache: "no-store" }).then((r) => { if (!r.ok) throw 0; return r.json(); })
    .catch(() => fetch("/products.json?v=" + Date.now()).then((r) => r.json()));
  const fx = fetch("/api/fx").then((r) => r.json()).then((d) => { if (d && d.rates) FX = d.rates; }).catch(() => {});
  return Promise.all([src, fx]).then(([d]) => {
    let force = ""; try { force = new URLSearchParams(location.search).get("pay") || ""; } catch (e) {}
    CUR = /^(EUR|USD)$/.test(force) ? force : d.pay || d.currency || "EUR";
    PRODUCTS = d.products.filter((p) => (p.status || "live") === "live").map((p) => ({ ...p, priceEur: p.price, price: CUR === "USD" ? Number(p.priceUsd || p.price) : p.price, sounds: (p.sounds || []).filter((s) => !s.hidden) }));
    DEALS = d.deals || DEALS;
    WORLDS = d.worlds.filter((w) => PRODUCTS.some((p) => p.world === w.id));
    cart = cart.filter(byId); saveCart(); curUI();
    if (DRAFT) { const b = document.createElement("div"); b.textContent = "PREVIEW · NOT LIVE"; b.style.cssText = "position:fixed;left:0;bottom:0;z-index:90;background:#8b6cf6;color:#0b0a0e;font:800 10px/1 Inter,sans-serif;letter-spacing:.2em;padding:9px 10px"; document.body.appendChild(b); }
    if (PRODUCTS.some((p) => p.payhip || p.payhipFree)) { const s = document.createElement("script"); s.src = "https://payhip.com/payhip.js"; document.body.appendChild(s); }
    CLARITY = d.clarity || "";
    trackVisit(); setTimeout(consentBar, 1200); loadClarity();
    const ft = $("footer .wrap"); if (ft && !$("footer [data-cookies]")) ft.insertAdjacentHTML("beforeend", `<span class="ftl"><a href="/privacy">Privacy</a><button class="ckl" data-cookies>Cookies</button></span>`);
    const pm = location.pathname.match(/^\/pack\/([^/?#]+)/);
    track("view", pm ? decodeURIComponent(pm[1]) : null, location.pathname);
    if (pm) track("pack", decodeURIComponent(pm[1]));
    if (location.pathname === "/checkout") track("checkout", null, String(cart.length), total());
    return loadLoyalty().catch(() => {});
  });
}

/* ---------- waveforms (same look as the KILLTOY review pages) ---------- */
const BARS = 96, peaks = new Map(), pending = new Map();
let actx = null;
function getPeaks(src) {
  if (peaks.has(src)) return Promise.resolve(peaks.get(src));
  try { const c = JSON.parse(localStorage.getItem("ck-wf:" + src) || "null"); if (c) { peaks.set(src, c); return Promise.resolve(c); } } catch (e) {}
  if (pending.has(src)) return pending.get(src);
  const job = fetch(src).then((r) => r.arrayBuffer()).then((buf) => {
    actx = actx || new (window.OfflineAudioContext || window.webkitOfflineAudioContext)(1, 1, 44100);
    return new Promise((ok, bad) => actx.decodeAudioData(buf, ok, bad));
  }).then((ab) => {
    const d = ab.getChannelData(0), step = Math.floor(d.length / BARS) || 1, out = [];
    for (let i = 0; i < BARS; i++) { let m = 0; for (let j = i * step, e = Math.min(d.length, j + step); j < e; j += 4) { const v = Math.abs(d[j]); if (v > m) m = v; } out.push(m); }
    const top = Math.max(...out) || 1, w = out.map((v) => Math.round((v / top) * 100) / 100);
    peaks.set(src, w); try { localStorage.setItem("ck-wf:" + src, JSON.stringify(w)); } catch (e) {}
    return w;
  }).catch(() => null);
  pending.set(src, job); return job;
}
function drawWave(btn, ph) {
  const cv = btn.querySelector("canvas.wf"); if (!cv) return;
  const w = peaks.get(btn.dataset.src), r = cv.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
  const W = Math.max(20, Math.round(r.width)), H = Math.round(r.height); if (!H) return;
  if (cv.width !== W * dpr || cv.height !== H * dpr) { cv.width = W * dpr; cv.height = H * dpr; }
  const g = cv.getContext("2d"); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
  const on = btn === curBtn, n = w ? w.length : BARS, bw = W / n;
  for (let i = 0; i < n; i++) {
    const v = w ? Math.max(0.04, w[i]) : 0.04, h = v * (H - 2), past = on && ph != null && i / n <= ph;
    g.fillStyle = past ? "#e4ff3a" : on ? "#b8a4ff" : "#8b6cf6"; g.globalAlpha = past ? 1 : 0.85;
    g.fillRect(i * bw + 0.5, (H - h) / 2, Math.max(1, bw - 1.2), h);
  }
  g.globalAlpha = 1;
}
const waveIO = "IntersectionObserver" in window ? new IntersectionObserver((es) => es.forEach((e) => {
  if (!e.isIntersecting) return; waveIO.unobserve(e.target);
  const b = e.target; drawWave(b); getPeaks(b.dataset.src).then(() => drawWave(b));
}), { rootMargin: "200px" }) : null;
function watchWaves(root = document) {
  root.querySelectorAll(".pv button").forEach((b) => { if (waveIO) waveIO.observe(b); else getPeaks(b.dataset.src).then(() => drawWave(b)); });
}
let rsz; addEventListener("resize", () => { clearTimeout(rsz); rsz = setTimeout(() => document.querySelectorAll(".pv button").forEach((b) => peaks.has(b.dataset.src) && drawWave(b, b === curBtn ? audio.currentTime / (audio.duration || 1) : null)), 120); });

/* ---------- previews: one sound at a time, tap the wave to jump ---------- */
const audio = new Audio(); audio.preload = "none"; let curBtn = null;
function stopCur() { const b = curBtn; if (b) { b.classList.remove("on"); $(".pl", b).innerHTML = PLAY; } curBtn = null; if (b) drawWave(b); }
function tick() { if (!curBtn) return; drawWave(curBtn, audio.duration ? audio.currentTime / audio.duration : 0); requestAnimationFrame(tick); }
document.addEventListener("click", (e) => {
  const b = e.target.closest(".pv button"); if (!b) return;
  const cv = e.target.closest("canvas.wf");
  const at = cv ? Math.min(0.99, Math.max(0, (e.clientX - cv.getBoundingClientRect().left) / cv.getBoundingClientRect().width)) : null;
  if (curBtn === b) {
    if (at != null && audio.duration) { audio.currentTime = at * audio.duration; return; }
    audio.pause(); stopCur(); return;
  }
  stopCur(); curBtn = b; b.classList.add("on"); $(".pl", b).innerHTML = STOP;
  audio.src = b.dataset.src; audio.currentTime = 0;
  if (at != null) audio.addEventListener("loadedmetadata", () => { if (curBtn === b) audio.currentTime = at * audio.duration; }, { once: true });
  audio.play().then(() => requestAnimationFrame(tick)).catch(stopCur);
  getPeaks(b.dataset.src).then(() => drawWave(b, 0));
  const row = b.closest("[data-id]"), pm = location.pathname.match(/^\/pack\/([^/?#]+)/);
  track("play", row ? row.dataset.id : pm ? decodeURIComponent(pm[1]) : null, ($(".nm", b) || {}).textContent);
});
audio.addEventListener("ended", stopCur);

/* plastic covers lean toward the mouse (desktop) */
if (matchMedia("(hover:hover)").matches) {
  document.addEventListener("pointermove", (e) => {
    const q = e.target.closest && e.target.closest(".pq");
    document.querySelectorAll(".pq.tl").forEach((x) => { if (x !== q) { x.classList.remove("tl"); x.style.transform = ""; x.firstElementChild.nextElementSibling.style.backgroundPosition = ""; } });
    if (!q) return;
    const r = q.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
    q.classList.add("tl");
    q.style.transform = `perspective(800px) rotateX(${(-y * 10).toFixed(2)}deg) rotateY(${(x * 12).toFixed(2)}deg) translateY(-3px)`;
    q.querySelector(".gl").style.backgroundPosition = `${(50 + x * 80).toFixed(1)}% 50%, 0 0`;
  }, { passive: true });
}

/* ---------- loyalty meter (corner) ---------- */
const myEmail = () => { try { return localStorage.getItem("ck-email") || ""; } catch (e) { return ""; } };
const demoLoy = () => { try { return JSON.parse(localStorage.getItem("ck-loy-demo") || '{"paid":0,"used":0}'); } catch (e) { return { paid: 0, used: 0 }; } };
function loadLoyalty() {
  const em = myEmail(), d = demoLoy();
  const base = em ? fetch("/api/loyalty?email=" + encodeURIComponent(em)).then((r) => r.json()).catch(() => ({ paid: 0, used: 0 })) : Promise.resolve({ paid: 0, used: 0 });
  return base.then((b) => { const paid = (b.paid || 0) + d.paid, used = (b.used || 0) + d.used; LOY = { paid, picks: Math.floor(paid / LOY_N) - used }; paintLoy(); return LOY; });
}
function loyHTML(paid, picks) {
  const k = paid % LOY_N, left = LOY_N - k;
  return `<div class="loyh"><b>Loyalty</b><span>${k * (100 / LOY_N)}%</span></div>
    <div class="loyb">${Array.from({ length: LOY_N }, (_, i) => `<i class="${i < k ? "on" : ""}"></i>`).join("")}</div>
    ${cardLive() ? `<button class="loyc" data-mycard style="--cc:${cardDef().color}">★ ${esc(cardDef().name)} · ${esc(cardDef().label)}</button>` : ""}
    <div class="loyt">${picks > 0 ? `<em>★ ${picks} free pick${picks > 1 ? "s" : ""}</em> · ` : ""}${left === 1 ? "1 more pack → free pack" : left + " more packs → free pack"}</div>`;
}
function paintLoy() {
  if (!myEmail() && !LOY.paid) return;
  let el = $("#loy"); if (!el) { el = document.createElement("div"); el.id = "loy"; el.className = "loy"; document.body.appendChild(el); }
  el.innerHTML = loyHTML(LOY.paid, LOY.picks);
}
/* little game sound: coin blips, a chord when a free pack is earned */
function blip(i, big) {
  try {
    const C = blip.c || (blip.c = new (window.AudioContext || window.webkitAudioContext)()), t = C.currentTime;
    const notes = big ? [523, 659, 784, 1047] : [660 + i * 110, 990 + i * 110];
    notes.forEach((f, j) => { const o = C.createOscillator(), g = C.createGain(); o.type = "square"; o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t + j * 0.07); g.gain.exponentialRampToValueAtTime(0.06, t + j * 0.07 + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + j * 0.07 + (big ? 0.35 : 0.12));
      o.connect(g).connect(C.destination); o.start(t + j * 0.07); o.stop(t + j * 0.07 + 0.4); });
  } catch (e) {}
}
/* fill the meter one block at a time after a purchase */
function loyGain(n, quiet) {
  const start = LOY.paid; LOY.paid += n;
  let el = $("#loy"); if (!el) { el = document.createElement("div"); el.id = "loy"; el.className = "loy"; document.body.appendChild(el); }
  el.classList.add("big");
  let step = 0, picks = LOY.picks;
  el.innerHTML = loyHTML(start, picks);
  const tick = () => {
    if (step >= n) { LOY.picks = picks; setTimeout(() => { el.classList.remove("big"); paintLoy(); }, 1600); return; }
    step++; const p = start + step, done = p % LOY_N === 0;
    if (done) picks++;
    el.innerHTML = loyHTML(done ? p - 1 : p, picks - (done ? 1 : 0));
    if (done) { el.querySelectorAll(".loyb i").forEach((x) => x.classList.add("on")); el.querySelector(".loyh span").textContent = "100%"; el.querySelector(".loyt").innerHTML = "<em>★ +1 free pick</em> · use it on any pack"; }
    el.querySelector(`.loyb i:nth-child(${done ? LOY_N : p % LOY_N})`).classList.add("pop");
    if (!quiet) blip(step, done);
    if (done) { el.classList.add("win"); el.insertAdjacentHTML("beforeend", `<div class="loyw">Free pack earned</div>`); setTimeout(() => el.classList.remove("win"), 1400); setTimeout(tick, 1500); }
    else setTimeout(tick, 420);
  };
  setTimeout(tick, 500);
}

/* ---------- visits (only remembered after a yes) ---------- */
const consent = () => { try { return localStorage.getItem("ck-consent"); } catch (e) { return null; } };
function act() { try { return JSON.parse(localStorage.getItem("ck-act") || "null") || { visits: 0, first: Date.now(), last: 0, secs: 0, viewed: [] }; } catch (e) { return { visits: 0, first: Date.now(), last: 0, secs: 0, viewed: [] }; } }
const saveAct = (a) => { try { localStorage.setItem("ck-act", JSON.stringify(a)); } catch (e) {} };
let GAP = 0;   // days since the visit before this one
function trackVisit() {
  if (consent() !== "yes") return;
  const a = act();
  let fresh = false; try { fresh = !sessionStorage.getItem("ck-s"); sessionStorage.setItem("ck-s", "1"); } catch (e) {}
  if (fresh) { GAP = a.last ? (Date.now() - a.last) / 864e5 : 0; try { sessionStorage.setItem("ck-gap", String(GAP)); } catch (e) {} a.visits++; }
  else { try { GAP = +sessionStorage.getItem("ck-gap") || 0; } catch (e) {} }
  a.last = Date.now();
  const m = location.pathname.match(/^\/pack\/([^/?#]+)/); if (m && !a.viewed.includes(m[1])) a.viewed.push(m[1]);
  saveAct(a);
  setInterval(() => { if (document.visibilityState === "visible") { const b = act(); b.secs += 15; b.last = Date.now(); saveAct(b); } }, 15000);
}
const recOK = () => { try { return consent() === "yes" && localStorage.getItem("ck-rec") !== "0"; } catch (e) { return false; } };
function setConsent(yes, rec) {
  if (rec === undefined) rec = yes;
  try { localStorage.setItem("ck-consent", yes ? "yes" : "no"); localStorage.setItem("ck-rec", rec ? "1" : "0"); if (!yes) ["ck-act", "ck-vid", "ck-ref"].forEach((k) => localStorage.removeItem(k)); } catch (e) {}
  const b = $("#consent"); if (b) b.remove();
  if (yes) { trackVisit(); loadClarity(); track("consent"); }
}
function consentBar() {
  if (consent() || $("#consent")) return;
  document.body.insertAdjacentHTML("beforeend", `<div class="consent" id="consent"><span>Can we use cookies for anonymous stats? No names, never sold.</span>
    <div class="cbtns"><button class="btn sm" data-consent="yes">Allow</button><button class="btn sm" data-consent="no">Only necessary</button></div>
    <button class="ckl" id="cMore">See more</button>
    <div class="cmore" id="cMoreTx" hidden>
      <label class="ctg"><input type="checkbox" disabled checked><span><b>Necessary</b> · cart, currency and the email you type, kept in this browser. Always on.</span></label>
      <label class="ctg"><input type="checkbox" id="cStats"><span><b>Stats</b> · a random visitor number, return visits, pages, clicks and sample plays. Stored by COREKULT on Cloudflare in the EU, deleted after 12 months.</span></label>
      <label class="ctg"><input type="checkbox" id="cRec"><span><b>Heatmaps + recordings</b> · clicks, scrolls and screen recordings by Microsoft Clarity, all typing blurred. Recordings kept 30 days, heatmaps 13 months.</span></label>
      <p class="cwhy">Why: to see which packs and sounds people like and make the shop easier to use. Never sold, never used for ads. Change or take back your choice any time with Cookies at the bottom of the page. Questions or delete requests: hello@corekult.com · <a href="/privacy">Privacy</a></p>
      <button class="btn sm" data-consent="pick">Save my choice</button>
    </div></div>`);
}
/* ---------- claim: one click, card spins ---------- */
function claimBlock(em) {
  let b = $("#frClaim");
  if (!b) { b = document.createElement("div"); b.id = "frClaim"; b.className = "claim"; $("#frList").after(b); }
  const has = cardLive();
  b.hidden = false;
  b.setAttribute("data-clarity-mask", "true");
  b.innerHTML = `<small>Is this you?</small><div class="me"><b>${esc(em)}</b><button id="claimEdit" aria-label="Change email">✎</button></div>
    <button class="btn acid wide" id="claimGo">${has ? "Show my card" : "Claim my deal card"}</button>`;
}
function claim() {
  const em = myEmail(); if (!em) return;
  if (cardLive() && CARD.email === em.toLowerCase()) { showCard(CARD, false); return; }
  $("#claimGo").disabled = true;
  fetch("/api/claim", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ email: em }) })
    .then((r) => r.json()).then((r) => {
      $("#claimGo").disabled = false; if (!r.ok) return;
      track("claim", null, r.card.tier); CARD = r.card; try { localStorage.setItem("ck-card", JSON.stringify(CARD)); } catch (e) {}
      closeDrawer(); showCard(CARD, !r.again); paintLoy(); paintCart();
    }).catch(() => { $("#claimGo").disabled = false; });
}
const muted = () => { try { return localStorage.getItem("ck-mute") === "1"; } catch (e) { return false; } };
function setMute(m) { try { localStorage.setItem("ck-mute", m ? "1" : "0"); } catch (e) {} const b = $("#cardMute"); if (b) b.classList.toggle("off", m); }
function tone(f, at, len, type, vol) {
  if (muted()) return;
  try {
    const C = blip.c || (blip.c = new (window.AudioContext || window.webkitAudioContext)()), t = C.currentTime + at, o = C.createOscillator(), g = C.createGain();
    o.type = type || "square"; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol || 0.05, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t + len);
    o.connect(g).connect(C.destination); o.start(t); o.stop(t + len + 0.05);
  } catch (e) {}
}
const fmtDate = (ms) => new Date(ms).toLocaleDateString("en-GB", { day: "numeric", month: "short" });
function showCard(card, spin) {
  const c = (DEALS.cards || []).find((x) => x.id === card.tier); if (!c) return;
  closeCard();
  document.body.insertAdjacentHTML("beforeend", `<div class="cardov" id="cardOv" data-clarity-mask="true">
    <button class="cardmute${muted() ? " off" : ""}" id="cardMute" aria-label="Sound on or off"><svg viewBox="0 0 16 16"><path d="M2 6h3l4-3v10l-4-3H2z"/><path class="w" d="M11 5.5c1 .8 1 4.2 0 5M12.8 4c2 1.6 2 6.4 0 8" fill="none" stroke="currentColor" stroke-width="1.3"/></svg></button>
    <button class="x" id="cardX" aria-label="Close">×</button>
    <div class="dstage"><div class="dcard${spin ? " spin" : ""}" id="dCard" style="--cc:${c.color}">
      <div class="dface dback"><img src="/img/logo-white.png?v=2" alt="COREKULT"><i class="gl"></i></div>
      <div class="dface dfront"><span class="drar">${esc(c.name)}</span><span class="dyour">Your card</span><b class="ddeal">${esc(c.label)}</b>
        <span class="dcode">${esc(card.code)}</span><span class="dexp">Use by ${fmtDate(card.exp)}</span><i class="gl"></i></div>
    </div></div>
    <p class="dnote">Your card is based on your activity with this email. Works at checkout with ${esc(card.email || myEmail())}.</p>
    <div class="dbtns"><a class="btn acid" href="/checkout${QS}">Use it now</a><button class="btn" id="cardLater">Later</button></div>
  </div>`);
  document.body.classList.add("lock");
  if (!spin) return;
  // ticks slow down as the card turns, then a chord when it lands
  let t = 0; for (let i = 0; i < 11; i++) { t += 0.06 + i * i * 0.0065; tone(900 - i * 30, t, 0.05, "square", 0.035); }
  [523, 659, 784, 1047, 1319].forEach((f, j) => tone(f, 2.75 + j * 0.06, 0.6, "triangle", 0.06));
  setTimeout(() => { const d = $("#dCard"); if (d) d.classList.add("landed"); }, 2750);
}
function closeCard() { const o = $("#cardOv"); if (o) { o.remove(); document.body.classList.remove("lock"); } }

/* ---------- stats: anonymous counts; visitor id, referral memory and recordings only after cookie OK ---------- */
let CLARITY = "";
const rid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
(function catchRef() {
  let r = ""; try { r = (new URLSearchParams(location.search).get("ref") || "").toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 40); } catch (e) {}
  if (!r) return;
  try { sessionStorage.setItem("ck-ref", r); } catch (e) {}
  if (consent() === "yes") try { localStorage.setItem("ck-ref", JSON.stringify({ r, ts: Date.now() })); } catch (e) {}
})();
function getRef() {
  try { const s = sessionStorage.getItem("ck-ref"); if (s) return s; } catch (e) {}
  if (consent() !== "yes") return null;
  try { const l = JSON.parse(localStorage.getItem("ck-ref") || "null"); if (l && Date.now() - l.ts < 30 * 864e5) return l.r; } catch (e) {}
  return null;
}
function ids() {
  if (consent() !== "yes") return {};
  let vid = "", sid = "";
  try { vid = localStorage.getItem("ck-vid") || ""; if (!vid) { vid = rid(); localStorage.setItem("ck-vid", vid); } } catch (e) {}
  try { sid = sessionStorage.getItem("ck-sid") || ""; if (!sid) { sid = rid(); sessionStorage.setItem("ck-sid", sid); } } catch (e) {}
  return { vid, sid };
}
let evQ = [], evT = 0;
function track(t, pack, x, val) {
  if (DRAFT) return;
  evQ.push({ t, pack: pack || null, x: x == null ? null : String(x), val: val == null ? null : val });
  clearTimeout(evT); evT = setTimeout(flushEv, 600);
}
function flushEv() {
  if (!evQ.length) return;
  const body = JSON.stringify({ e: evQ.splice(0, 20), ref: getRef(), ...ids() });
  if (!(navigator.sendBeacon && navigator.sendBeacon("/api/ev", new Blob([body], { type: "text/plain" })))) fetch("/api/ev", { method: "POST", body, keepalive: true }).catch(() => {});
  if (evQ.length) flushEv();
}
addEventListener("pagehide", flushEv);
/* Microsoft Clarity heatmaps + recordings: only after OK; inputs are masked by Clarity, private bits marked data-clarity-mask */
function loadClarity() {
  if (!recOK() || !CLARITY || window.clarity) return;
  (function (c, l, a, r, i) { c[a] = c[a] || function () { (c[a].q = c[a].q || []).push(arguments); }; const t = l.createElement(r); t.async = 1; t.src = "https://www.clarity.ms/tag/" + i; const y = l.getElementsByTagName(r)[0]; y.parentNode.insertBefore(t, y); })(window, document, "clarity", "script", CLARITY);
  window.clarity("consent");
}
