/* COREKULT admin + work area. One data file (packs) shared with the public shop.
   Changes stay a local draft until SAVE; PREVIEW shows the shop with the draft. */
"use strict";
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const PAGE = document.body.dataset.page;               // "admin" | "work"
const DRAFT_KEY = "ck-draft";
let S = { packs: null, saved: "", sales: [], storage: false, webhook: "", open: null, range: 30, demo: false };

const money = (n, cur) => new Intl.NumberFormat("en-IE", { style: "currency", currency: cur || (S.packs && S.packs.currency) || "EUR", maximumFractionDigits: n % 1 ? 2 : 0 }).format(n || 0);
const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "pack";
const dirty = () => JSON.stringify(S.packs) !== S.saved;
function toast(t) { const el = $("#toast"); el.textContent = t; el.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => (el.hidden = true), 1800); }
function keepDraft() {
  try { localStorage.setItem(DRAFT_KEY, JSON.stringify(S.packs)); } catch (e) {}
  $("#save").disabled = !dirty() || !S.storage;
  $("#dirty").hidden = !dirty();
}

async function load() {
  const r = await fetch("/api/admin/state", { cache: "no-store" });
  if (r.status === 401) { location.href = "/login?next=" + encodeURIComponent(location.pathname); return; }
  const d = await r.json();
  S.storage = d.storage; S.webhook = d.webhook; S.sales = d.sales || []; S.leads = d.leads || [];
  S.packs = d.packs;
  S.packs.products.forEach((p) => { p.status = p.status || "live"; p.sounds = p.sounds || []; });
  S.saved = JSON.stringify(S.packs);
  // an unsaved draft from before wins
  try { const dr = JSON.parse(localStorage.getItem(DRAFT_KEY) || "null"); if (dr && dr.products && JSON.stringify(dr) !== S.saved) { S.packs = dr; toast("Unsaved changes restored"); } } catch (e) {}
  if (!S.storage) $("#warn").hidden = false;
  render(); keepDraft();
}

async function save() {
  const r = await fetch("/api/admin/packs", { method: "PUT", headers: { "content-type": "application/json" }, body: JSON.stringify(S.packs) });
  const d = await r.json().catch(() => ({}));
  if (!d.ok) { toast("Save failed"); return false; }
  S.saved = JSON.stringify(S.packs); keepDraft(); toast("Saved · live on corekult.com"); return true;
}
async function undo() {
  const r = await fetch("/api/admin/undo", { method: "POST" });
  const d = await r.json().catch(() => ({}));
  if (!d.ok) { toast("Nothing to undo"); return; }
  try { localStorage.removeItem(DRAFT_KEY); } catch (e) {}
  await load(); toast("Last save undone");
}
async function upload(file) {
  const r = await fetch("/api/admin/upload?name=" + encodeURIComponent(file.name), { method: "POST", headers: { "content-type": file.type || "application/octet-stream" }, body: file });
  const d = await r.json().catch(() => ({}));
  if (!d.ok) { toast(d.error === "storage" ? "Storage not set up yet" : "Upload failed"); return null; }
  return d.url;
}
function pick(accept) {
  return new Promise((res) => { const i = document.createElement("input"); i.type = "file"; i.accept = accept; i.onchange = () => res(i.files[0] || null); i.click(); });
}

/* ============ PREVIEW ============ */
function preview(hash) {
  keepDraft();
  const pv = $("#pv");
  $("#pvf").src = "/?draft=1&t=" + Date.now() + (hash ? "#" + hash : "");
  pv.hidden = false;
}

/* ============ OVERVIEW ============ */
function demoSales() {
  const out = [], ps = S.packs.products.filter((p) => p.status === "live");
  let seed = 7; const rnd = () => ((seed = (seed * 9301 + 49297) % 233280) / 233280);
  for (let d = 89; d >= 0; d--) {
    const n = Math.floor(rnd() * (d < 30 ? 6 : 3));
    for (let k = 0; k < n; k++) {
      const items = [ps[Math.floor(rnd() * ps.length)]];
      if (rnd() > .8) items.push(ps[Math.floor(rnd() * ps.length)]);
      out.push({ date: new Date(Date.now() - d * 864e5).toISOString(), total: items.reduce((s, p) => s + p.price, 0), items: items.map((p) => ({ key: p.payhip || p.id, name: p.name })), country: ["SE", "US", "DE", "UK", "FR", "NO"][Math.floor(rnd() * 6)], via: rnd() > .3 ? "card" : "paypal", type: "paid" });
    }
  }
  return out;
}
function overview() {
  const all = (S.demo ? demoSales() : S.sales).filter((s) => s.type !== "refunded");
  const since = Date.now() - S.range * 864e5;
  const sales = all.filter((s) => new Date(s.date).getTime() >= since);
  const rev = sales.reduce((s, x) => s + Number(x.total || 0), 0);
  const days = [];
  for (let d = S.range - 1; d >= 0; d--) {
    const day = new Date(Date.now() - d * 864e5).toISOString().slice(0, 10);
    days.push({ day, v: sales.filter((s) => s.date.slice(0, 10) === day).reduce((a, x) => a + Number(x.total || 0), 0) });
  }
  const max = Math.max(1, ...days.map((d) => d.v));
  const W = 700, H = 200, bw = W / days.length;
  const bars = days.map((d, i) => { const h = (d.v / max) * (H - 24); return `<rect x="${(i * bw + 1).toFixed(1)}" y="${(H - 18 - h).toFixed(1)}" width="${Math.max(1, bw - 2).toFixed(1)}" height="${Math.max(d.v ? 2 : 0, h).toFixed(1)}" fill="${i === days.length - 1 ? "#e4ff3a" : "#8b6cf6"}"><title>${d.day} · ${money(d.v)}</title></rect>`; }).join("");
  const lbl = [0, Math.floor(days.length / 2), days.length - 1].map((i) => `<text x="${(i * bw + bw / 2).toFixed(1)}" y="${H - 4}" fill="rgba(236,235,240,.5)" font-size="10" font-family="JetBrains Mono" text-anchor="middle">${days[i].day.slice(5)}</text>`).join("");
  const per = {};
  sales.forEach((s) => (s.items || []).forEach((i) => { const n = i.name || i.key; per[n] = (per[n] || 0) + 1; }));
  const top = Object.entries(per).sort((a, b) => b[1] - a[1]);
  const pmax = Math.max(1, ...top.map((t) => t[1]));
  const live = S.packs.products.filter((p) => p.status === "live").length;
  $("#main").innerHTML = `
    <div class="row" style="justify-content:space-between;margin-bottom:14px"><h1 style="margin:0">Overview</h1>
      <div class="row"><div class="seg" id="rng">${[7, 30, 90].map((n) => `<button data-r="${n}" class="${S.range === n ? "on" : ""}">${n} days</button>`).join("")}</div>
      <div class="seg"><button id="demo" class="${S.demo ? "on" : ""}">Demo data</button></div></div></div>
    ${!S.sales.length && !S.demo ? `<div class="warn">No sales yet. Turn on DEMO DATA to see how this page looks with sales.</div>` : ""}
    ${S.demo ? `<div class="warn">Demo data · not real sales</div>` : ""}
    <div class="kpis">
      <div class="kpi acid"><span>Revenue</span><b>${money(rev)}</b></div>
      <div class="kpi"><span>Orders</span><b>${sales.length}</b></div>
      <div class="kpi"><span>Avg order</span><b>${money(sales.length ? rev / sales.length : 0)}</b></div>
      <div class="kpi"><span>Packs live</span><b>${live}<small style="font-size:14px;color:var(--ink2)"> / ${S.packs.products.length}</small></b></div>
    </div>
    <div class="charts">
      <div class="chart"><h3>Revenue per day</h3><svg viewBox="0 0 ${W} ${H}">${bars}${lbl}</svg></div>
      <div class="chart"><h3>Best sellers</h3><div class="hb">${top.length ? top.slice(0, 8).map(([n, c]) => `<div><span>${esc(n)}</span><i style="width:${(c / pmax) * 100}%"></i><em>${c}</em></div>`).join("") : `<span class="note">No sales in this range</span>`}</div></div>
    </div>
    <h2>Latest orders</h2>
    <table><thead><tr><th>Date</th><th>Packs</th><th>Total</th><th>Paid with</th><th>Country</th></tr></thead><tbody>
    ${sales.slice().reverse().slice(0, 15).map((s) => `<tr><td>${s.date.slice(0, 16).replace("T", " ")}</td><td>${esc((s.items || []).map((i) => i.name || i.key).join(", "))}</td><td>${money(s.total, s.currency)}</td><td>${esc(s.via || "")}</td><td>${esc(s.country || "")}</td></tr>`).join("") || `<tr><td colspan="5" class="note">No orders yet</td></tr>`}
    </tbody></table>
    <h2>Emails from free packs <small style="font-size:12px;color:var(--ink2)">${(S.leads || []).length}</small></h2>
    <table><thead><tr><th>Email</th><th>Free packs</th><th>Country</th><th>Date</th></tr></thead><tbody>
    ${(S.leads || []).slice().reverse().slice(0, 50).map((l) => `<tr><td>${esc(l.email)}</td><td>${esc((l.packs || []).join(", "))}</td><td>${esc(l.country || "")}</td><td>${esc((l.last || l.first || "").slice(0, 10))}</td></tr>`).join("") || `<tr><td colspan="4" class="note">No emails yet</td></tr>`}
    </tbody></table>
    ${(S.leads || []).length ? `<div class="seg" style="margin-top:8px"><button id="leadsCsv">Download emails (CSV)</button></div>` : ""}
    <h2>Sales connection</h2>
    <div class="note">Payhip → Settings → Developer → Webhooks → paste this URL<br><span style="color:var(--acid);user-select:all">${esc(S.webhook)}</span></div>`;
}

/* ============ PACKS (admin) ============ */
const STATUS = [["live", "Live"], ["hidden", "Hidden"]];
function packsView() {
  const ps = S.packs.products;
  $("#main").innerHTML = `
    <div class="row" style="justify-content:space-between;margin-bottom:14px"><h1 style="margin:0">Packs</h1>
      <div class="row"><button class="b" id="addPack">+ New pack</button></div></div>
    <div class="packs" id="plist">${ps.map(packRow).join("")}</div>`;
  dragList($("#plist"), ".pk", (from, to) => { const [m] = ps.splice(from, 1); ps.splice(to, 0, m); keepDraft(); packsView(); });
}
function packRow(p, i) {
  const open = S.open === p.id;
  const worlds = S.packs.worlds;
  return `<div class="pk ${p.status !== "live" ? "off" : ""}" data-i="${i}" data-id="${p.id}">
    <div class="pkh" data-toggle="${p.id}"><span class="grip" draggable="true" title="Drag to reorder">⋮⋮</span><img src="${esc(p.cover)}" alt="">
      <div><b>${esc(p.name)}</b><small>${esc((worlds.find((w) => w.id === p.world) || {}).name || p.world)} · ${esc(p.sub)} · ${p.sounds.filter((s) => !s.hidden).length}/${p.sounds.length} sounds shown</small></div>
      <span class="pr">${money(p.price)}</span><span class="st ${p.status}">${esc(p.status)}</span><span class="note">${open ? "▲" : "▼"}</span></div>
    <div class="pkb" ${open ? "" : "hidden"}>
      <div class="cvbox"><img src="${esc(p.cover)}" alt=""><button class="b" data-cover="${p.id}">Change cover</button><button class="b" data-pv="${p.id}">Preview on site</button></div>
      <div class="fields">
        <label class="f w2">Name<input data-k="name" value="${esc(p.name)}"></label>
        <label class="f">Price<span class="pin"><span>€</span><input data-k="price" type="number" min="0" step="1" value="${esc(p.price)}"></span></label>
        <div class="f">Status<div class="tg">${STATUS.map(([v, l]) => `<button data-st="${v}" class="${p.status === v ? "on" : ""}">${l}</button>`).join("")}</div></div>
        <label class="f">World<select data-k="world">${worlds.map((w) => `<option value="${w.id}" ${w.id === p.world ? "selected" : ""}>${esc(w.name)}</option>`).join("")}</select></label>
        <label class="f">Type<select data-k="type"><option value="serum" ${p.type === "serum" ? "selected" : ""}>Serum presets</option><option value="drums" ${p.type === "drums" ? "selected" : ""}>Drum kit</option></select></label>
        <label class="f">Subtitle<input data-k="sub" value="${esc(p.sub)}"></label>
        <label class="f">Count<input data-k="count" value="${esc(p.count)}"></label>
        <label class="f">Cover stamp<input data-k="stamp" value="${esc(p.stamp)}"></label>
        <div class="f">Badge<div class="tg"><button data-new class="${p.isNew ? "on" : ""}">New</button></div></div>
        <label class="f">Payhip key<input data-k="payhip" value="${esc(p.payhip)}" placeholder="from payhip.com/b/…"></label>
        <label class="f">Free samples key<input data-k="payhipFree" value="${esc(p.payhipFree)}" placeholder="payhip $0 product"></label>
        <label class="f w4">Text<textarea data-k="blurb">${esc(p.blurb)}</textarea></label>
        <div class="f w4">Sounds on the page · drag to reorder · eye hides it from the site
          <div class="snds" data-snds="${p.id}">${p.sounds.map((s, j) => `<div class="sn ${s.hidden ? "off" : ""}" data-j="${j}">
            <span class="grip" draggable="true">⋮⋮</span><button class="ic play" data-play="${esc(s.file)}">▶</button>
            <input data-sk="name" value="${esc(s.name)}"><input class="meta" data-sk="meta" value="${esc(s.meta)}" placeholder="BPM · key">
            <button class="ic eye ${s.hidden ? "offb" : ""}" data-eye title="${s.hidden ? "Hidden on the site" : "Shown on the site"}">${s.hidden ? "–" : "◉"}</button>
            <button class="ic" data-del title="Remove">×</button></div>`).join("")}</div>
          <div class="row" style="margin-top:6px"><button class="b" data-addsnd="${p.id}">+ Add sound</button></div>
        </div>
        <div class="f w4"><div class="row"><button class="b red" data-delpack="${p.id}">Delete pack</button></div></div>
      </div>
    </div></div>`;
}
const P = (id) => S.packs.products.find((p) => p.id === id);
function packOf(el) { const pk = el.closest(".pk"); return pk && P(pk.dataset.id); }

/* generic drag-reorder for a list of rows (works for packs and sounds) */
function dragList(box, sel, onMove) {
  if (!box) return;
  let from = null;
  box.addEventListener("dragstart", (e) => { const r = e.target.closest(sel); if (!r || r.parentElement !== box) return; from = [...box.children].indexOf(r); r.classList.add("drag"); e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", ""); e.stopPropagation(); });
  box.addEventListener("dragover", (e) => { if (from == null) return; const r = e.target.closest(sel); if (!r || r.parentElement !== box) return; e.preventDefault(); $$(".over", box).forEach((x) => x.classList.remove("over")); r.classList.add("over"); });
  box.addEventListener("drop", (e) => { if (from == null) return; const r = e.target.closest(sel); if (!r || r.parentElement !== box) return; e.preventDefault(); e.stopPropagation(); const to = [...box.children].indexOf(r); const f = from; from = null; if (to !== f) onMove(f, to); else render(); });
  box.addEventListener("dragend", () => { from = null; $$(".drag,.over", box).forEach((x) => x.classList.remove("drag", "over")); });
}
function wireSounds() {
  $$("[data-snds]").forEach((box) => {
    const p = P(box.dataset.snds);
    dragList(box, ".sn", (f, t) => { const [m] = p.sounds.splice(f, 1); p.sounds.splice(t, 0, m); keepDraft(); packsView(); wireSounds(); });
  });
}

/* ============ WORK AREA ============ */
const LANES = [["review", "In review", "review"], ["ready", "Ready to publish", "ready"], ["live", "Live on the shop", "live"]];
function workView() {
  const ps = S.packs.products;
  $("#main").innerHTML = `
    <div class="row" style="justify-content:space-between;margin-bottom:14px"><h1 style="margin:0">Work</h1>
      <div class="row"><button class="b" id="newReview">+ New pack in review</button></div></div>
    <div class="lanes">${LANES.map(([st, name, cls]) => {
      const list = ps.filter((p) => (st === "live" ? p.status === "live" || p.status === "hidden" : p.status === st));
      return `<div class="lane"><h3><span class="st ${cls}">${list.length}</span>${name}</h3>${list.map((p) => workCard(p, st)).join("") || `<span class="note">Empty</span>`}</div>`;
    }).join("")}</div>`;
}
function workCard(p, lane) {
  return `<div class="wc" data-id="${p.id}"><div class="hd"><img src="${esc(p.cover)}" alt=""><div><b>${esc(p.name)}</b><small>${esc(p.sub)} · ${money(p.price)}${p.status === "hidden" ? " · hidden" : ""}</small></div></div>
    <label class="f">Review page<input data-k="reviewUrl" value="${esc(p.reviewUrl || "")}" placeholder="link to the review page"></label>
    <textarea data-k="notes" placeholder="Notes">${esc(p.notes || "")}</textarea>
    <div class="row">${p.reviewUrl ? `<a class="b" href="${esc(p.reviewUrl)}" target="_blank" rel="noopener">Open review</a>` : ""}
      ${lane === "review" ? `<button class="b" data-move="ready">Ready</button>` : ""}
      ${lane === "ready" ? `<button class="b" data-move="review">Back to review</button><button class="b acid" data-publish>Publish</button>` : ""}
      ${lane === "live" ? `<button class="b" data-pv="${p.id}">See on site</button><button class="b" data-move="review">Unpublish</button>` : ""}
    </div></div>`;
}

/* ============ render + events ============ */
function render() {
  const view = PAGE === "work" ? "work" : (location.hash.slice(1) || "overview");
  $$(".tab[data-view]").forEach((t) => t.classList.toggle("on", t.dataset.view === view));
  if (view === "work") workView();
  else if (view === "packs") { packsView(); wireSounds(); }
  else overview();
}
window.addEventListener("hashchange", render);

document.addEventListener("input", (e) => {
  const t = e.target;
  if (t.dataset.k) { const p = packOf(t) || P(t.closest("[data-id]") && t.closest("[data-id]").dataset.id); if (!p) return; p[t.dataset.k] = t.dataset.k === "price" ? Math.max(0, Number(t.value) || 0) : t.value; keepDraft(); return; }
  if (t.dataset.sk) { const p = packOf(t); const j = +t.closest(".sn").dataset.j; p.sounds[j][t.dataset.sk] = t.value; keepDraft(); }
});
document.addEventListener("change", (e) => { if (e.target.dataset.k === "world" || e.target.dataset.k === "type") packsView(), wireSounds(); });

const audio = new Audio(); let playing = null;
document.addEventListener("click", async (e) => {
  const t = e.target;
  if (t.closest("#save")) { await save(); render(); return; }
  if (t.closest("#undo")) { if (confirmStep(t.closest("#undo"))) await undo(); return; }
  if (t.closest("#preview")) { preview(); return; }
  if (t.closest("#pvClose")) { $("#pv").hidden = true; $("#pvf").src = "about:blank"; return; }
  if (t.closest("#pvPhone")) { $("#pv").classList.toggle("phone"); t.closest("#pvPhone").classList.toggle("on"); return; }
  if (t.closest("#logout")) { await fetch("/api/logout"); location.href = "/login"; return; }
  const r = t.closest("[data-r]"); if (r) { S.range = +r.dataset.r; render(); return; }
  if (t.closest("#demo")) { S.demo = !S.demo; render(); return; }
  const pv = t.closest("[data-pv]"); if (pv) { preview("p-" + pv.dataset.pv); return; }
  if (t.closest(".grip")) return;
  const tog = t.closest("[data-toggle]"); if (tog) { S.open = S.open === tog.dataset.toggle ? null : tog.dataset.toggle; packsView(); wireSounds(); return; }
  const st = t.closest("[data-st]"); if (st) { packOf(st).status = st.dataset.st; keepDraft(); packsView(); wireSounds(); return; }
  const nw = t.closest("[data-new]"); if (nw) { const p = packOf(nw); p.isNew = !p.isNew; keepDraft(); packsView(); wireSounds(); return; }
  const pl = t.closest("[data-play]");
  if (pl) { if (playing === pl) { audio.pause(); pl.classList.remove("on"); playing = null; return; } if (playing) playing.classList.remove("on"); playing = pl; pl.classList.add("on"); audio.src = pl.dataset.play; audio.play().catch(() => {}); audio.onended = () => pl.classList.remove("on"); return; }
  const eye = t.closest("[data-eye]"); if (eye) { const p = packOf(eye); const s = p.sounds[+eye.closest(".sn").dataset.j]; s.hidden = !s.hidden; keepDraft(); packsView(); wireSounds(); return; }
  const del = t.closest("[data-del]"); if (del) { if (!confirmStep(del)) return; const p = packOf(del); p.sounds.splice(+del.closest(".sn").dataset.j, 1); keepDraft(); packsView(); wireSounds(); return; }
  const cv = t.closest("[data-cover]"); if (cv) { const f = await pick("image/*"); if (!f) return; const u = await upload(f); if (u) { P(cv.dataset.cover).cover = u; keepDraft(); packsView(); wireSounds(); } return; }
  const as = t.closest("[data-addsnd]"); if (as) { const f = await pick("audio/*"); if (!f) return; const u = await upload(f); if (u) { P(as.dataset.addsnd).sounds.push({ name: f.name.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " "), file: u, meta: "" }); keepDraft(); packsView(); wireSounds(); } return; }
  const dp = t.closest("[data-delpack]"); if (dp) { if (!confirmStep(dp)) return; S.packs.products = S.packs.products.filter((p) => p.id !== dp.dataset.delpack); keepDraft(); packsView(); wireSounds(); return; }
  if (t.closest("#addPack") || t.closest("#newReview")) {
    let id = "new-pack", n = 1; while (P(id)) id = "new-pack-" + ++n;
    S.packs.products.push({ id, world: S.packs.worlds[0].id, type: "serum", name: "New Pack", sub: "Serum Preset Pack", count: "", stamp: "SERUM 1 + 2", cover: "img/og.jpg", isNew: true, price: 19, blurb: "", payhip: "", payhipFree: "", sounds: [], status: PAGE === "work" ? "review" : "hidden", reviewUrl: "", notes: "" });
    S.open = id; keepDraft(); render(); return;
  }
  const mv = t.closest("[data-move]"); if (mv) { const p = P(mv.closest("[data-id]").dataset.id); p.status = mv.dataset.move; keepDraft(); workView(); return; }
  const pub = t.closest("[data-publish]"); if (pub) { const p = P(pub.closest("[data-id]").dataset.id); p.status = "live"; keepDraft(); if (await save()) toast(p.name + " is live"); workView(); return; }
});
/* destructive buttons need a second tap */
function confirmStep(b) {
  if (b.dataset.sure) return true;
  b.dataset.sure = "1"; const old = b.textContent; b.textContent = "Sure?"; b.classList.add("red");
  setTimeout(() => { delete b.dataset.sure; b.textContent = old; }, 2500);
  return false;
}
window.addEventListener("beforeunload", (e) => { if (dirty()) { e.preventDefault(); e.returnValue = ""; } });
load();

document.addEventListener("click", (e) => {
  if (!e.target.closest("#leadsCsv")) return;
  const rows = [["email", "packs", "country", "first", "last"], ...(S.leads || []).map((l) => [l.email, (l.packs || []).join(" "), l.country || "", l.first || "", l.last || ""])];
  const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([rows.map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n")], { type: "text/csv" }));
  a.download = "corekult-emails.csv"; a.click();
});
