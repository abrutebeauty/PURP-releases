/* COREKULT shop page: all packs. Click a pack to open its own page. Needs shop.js. */
$("#yr").textContent = new Date().getFullYear();

function render() {
  $("#stats").innerHTML = `<div><b>${PRODUCTS.length}</b>Packs</div><div><b>450+</b>Serum presets</div><div><b>3=2</b>Mix any packs</div>`;
  const chips = [["all", "All", PRODUCTS.length], ...WORLDS.map((w) => [w.id, w.name, PRODUCTS.filter((p) => p.world === w.id).length]), ["drums", "Drums", PRODUCTS.filter((p) => p.type === "drums").length]];
  $("#chips").innerHTML = chips.map(([id, n, c]) => `<button class="ch${id === "all" ? " on" : ""}" data-f="${id}">${esc(n)}<span class="n">${c}</span></button>`).join("");
  $("#worlds").innerHTML = WORLDS.map((w) => {
    const ps = PRODUCTS.filter((p) => p.world === w.id);
    return `<section class="world" id="${w.id}" data-world="${w.id}">
      <div class="wh"><h2 class="${w.font === "sans" ? "sans" : w.font === "it" ? "it" : ""}">${esc(w.name)}</h2><span class="vibe">${esc(w.vibe)}</span></div>
      <div class="grid">${ps.map(card).join("")}</div></section>`;
  }).join("");
}
function card(p) {
  const u = packUrl(p.id);
  return `<article class="card" data-type="${p.type}" id="p-${p.id}">
    <a class="cv" href="${u}"><span class="pq"><img src="${esc(abs(p.cover))}" alt="${esc(p.name)} cover" loading="lazy"><i class="gl"></i></span><span class="stamp">${esc(p.stamp)}</span>${p.isNew ? '<span class="badge">NEW</span>' : ""}</a>
    <div class="cb">
      <a class="ph" href="${u}"><div><div class="pn">${esc(p.name)}</div><div class="pf">${esc(p.sub)} · ${esc(p.count)}</div></div><div class="price">${show(p.price)}<small class="ps">${perSound(p)}</small></div></a>
      <p class="pi">${esc(p.blurb)}</p>
      <div class="buy"><a class="btn" href="${u}">View pack</a><button class="btn acid" data-add="${p.id}">Add to cart</button></div>
    </div></article>`;
}

document.addEventListener("click", (e) => {
  if (shopClick(e)) return;
  const ch = e.target.closest(".ch");
  if (ch) {
    document.querySelectorAll(".ch").forEach((c) => c.classList.toggle("on", c === ch));
    const f = ch.dataset.f;
    document.querySelectorAll(".world").forEach((w) => {
      const cards = [...w.querySelectorAll(".card")];
      cards.forEach((c) => c.hidden = f === "drums" ? c.dataset.type !== "drums" : false);
      w.hidden = f === "all" ? false : f === "drums" ? !cards.some((c) => !c.hidden) : w.dataset.world !== f;
    });
  }
});

document.addEventListener("ck-cur", () => { render(); paintCart(); });
loadShop().then(() => {
  render(); paintCart();
  if (location.hash.startsWith("#pack/")) { location.replace(packUrl(location.hash.slice(6))); return; }
  if (location.hash === "#cart" && cart.length) openCart();
  else if (location.hash.length > 1) { const el = document.getElementById(location.hash.slice(1)); if (el) el.scrollIntoView(); }
});
