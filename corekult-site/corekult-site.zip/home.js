/* COREKULT shop page: packs, pack dropdown, cart dropdown, free samples. Needs shop.js. */
$("#yr").textContent = new Date().getFullYear();

/* ---------- cart dropdown under the cart icon ---------- */
function addToCart(id) { if (!inCart(id)) cart.push(id); saveCart(); paintCart(); openCart(); }
function removeFromCart(id) { cart = cart.filter((x) => x !== id); saveCart(); paintCart(); }
function openCart() { paintCart(); $("#cartDd").hidden = false; $("#cartBtn").classList.add("open"); }
function closeCart() { $("#cartDd").hidden = true; $("#cartBtn").classList.remove("open"); }

function paintCart() {
  $("#cartN").textContent = cart.length;
  $("#cartN").hidden = !cart.length;
  document.querySelectorAll("[data-add]:not(.plus)").forEach((b) => {
    const on = inCart(b.dataset.add);
    b.textContent = on ? "In cart" : "Add to cart";
    b.classList.toggle("acid", !on); b.classList.toggle("ghost", on);
  });
  const items = cart.map(byId), free = freeIds(), off = dealOff();
  const pick = PRODUCTS.filter((p) => !inCart(p.id)).slice(0, 3);
  $("#cartDd").innerHTML = !items.length ? `<div class="empty">Your cart is empty.</div>` : `
    <div class="cdl">${items.map((p) => `<div class="ci">
        <img src="${esc(p.cover)}" alt="" data-open="${p.id}">
        <div class="cit"><b data-open="${p.id}">${esc(p.name)}</b><small>${esc(p.sub)} · ${esc(p.count)}</small><em>${esc(kinds(p))}</em></div>
        <div class="cip">${free.includes(p.id) ? `<span class="was">${money(p.price)}</span><span class="fr">FREE</span>` : money(p.price)}</div>
        <button class="x" data-rm="${p.id}" aria-label="Remove">×</button></div>`).join("")}</div>
    <div class="offer sm">${offerHTML()}</div>
    ${pick.length && dealStep() < 3 ? `<div class="cpk">${pick.map((p) => `<div class="cpi"><img src="${esc(p.cover)}" alt="" data-open="${p.id}"><b data-open="${p.id}">${esc(p.name)}</b><span>${money(p.price)}</span><button class="plus" data-add="${p.id}" aria-label="Add">+</button></div>`).join("")}</div>` : ""}
    <div class="cft">${off ? `<div class="row off"><span>3 for 2</span><span>−${money(off)}</span></div>` : ""}<div class="row tot"><span>Total</span><span>${money(total())}</span></div>
    <a class="btn acid wide" href="/checkout${DRAFT ? "?draft=1" : ""}">Checkout</a></div>`;
}

/* ---------- free samples drawer ---------- */
function openDrawer(view) {
  document.querySelectorAll(".dv").forEach((v) => v.hidden = v.dataset.v !== view);
  $("#drawer").classList.add("open"); $("#scrim").hidden = false; document.body.classList.add("lock");
}
function closeDrawer() { $("#drawer").classList.remove("open"); $("#scrim").hidden = true; document.body.classList.remove("lock"); }
function showFree(id) {
  const p = byId(id);
  $("#frName").textContent = p.name;
  $("#frCover").src = p.cover;
  $("#frList").innerHTML = p.sounds.map((s) => `<a class="li dl" href="${esc(s.file)}" download><span class="pl">↓</span><span>${esc(s.name)}</span><small>${esc(s.meta || "mp3")}</small></a>`).join("");
  $("#frList").hidden = true; $("#frForm").hidden = false; $("#frEmail").value = "";
  $("#frGo").onclick = () => {
    if (p.payhipFree && window.Payhip) { window.open("https://payhip.com/b/" + p.payhipFree, "_blank"); return; }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test($("#frEmail").value.trim())) { $("#frEmail").focus(); $("#frEmail").classList.add("bad"); return; }
    $("#frEmail").classList.remove("bad"); $("#frForm").hidden = true; $("#frList").hidden = false;
  };
  closeCart(); openDrawer("free");
}

/* ---------- page ---------- */
function render() {
  $("#stats").innerHTML = `<div><b>${PRODUCTS.length}</b>Packs</div><div><b>450+</b>Serum presets</div><div><b>3=2</b>Mix any packs</div>`;
  const chips = [["all", "All", PRODUCTS.length], ...WORLDS.map((w) => [w.id, w.name, PRODUCTS.filter((p) => p.world === w.id).length]), ["drums", "Drums", PRODUCTS.filter((p) => p.type === "drums").length]];
  $("#chips").innerHTML = chips.map(([id, n, c]) => `<button class="ch${id === "all" ? " on" : ""}" data-f="${id}">${esc(n)}<span class="n">${c}</span></button>`).join("");
  $("#worlds").innerHTML = WORLDS.map((w) => {
    const ps = PRODUCTS.filter((p) => p.world === w.id);
    return `<section class="world" id="${w.id}" data-world="${w.id}">
      <div class="wh"><h2 class="${w.font === "sans" ? "sans" : w.font === "it" ? "it" : ""}">${esc(w.name)}</h2><span class="vibe">${esc(w.vibe)}</span></div>
      <div class="grid">${ps.map(card).join("")}</div></section>`;
  }).join("");
}
function card(p) {
  return `<article class="card" data-type="${p.type}" id="p-${p.id}">
    <div class="cv" data-open="${p.id}"><img src="${esc(p.cover)}" alt="${esc(p.name)} cover" loading="lazy"><span class="stamp">${esc(p.stamp)}</span>${p.isNew ? '<span class="badge">NEW</span>' : ""}</div>
    <div class="cb">
      <div class="ph"><div><div class="pn" data-open="${p.id}">${esc(p.name)}</div><div class="pf">${esc(p.sub)} · ${esc(p.count)}</div></div><div class="price">${money(p.price)}</div></div>
      <p class="pi">${esc(p.blurb)}</p>
      <div class="pv">${sounds(p, 3)}</div>
      <div class="buy"><button class="btn" data-free="${p.id}">Free samples</button><button class="btn acid" data-add="${p.id}">Add to cart</button></div>
    </div></article>`;
}
function similar(p) {
  const score = (q) => (q.world === p.world ? 2 : 0) + (q.type === p.type ? 1 : 0);
  return PRODUCTS.filter((q) => q.id !== p.id).sort((a, b) => score(b) - score(a)).slice(0, 4);
}
/* a pack opens in place, under its row, with similar packs at the bottom */
function closePack() { const o = $("#pd"); if (o) o.remove(); document.querySelectorAll(".card.open").forEach((c) => c.classList.remove("open")); }
function openPack(id, scroll = true) {
  const p = byId(id), c = document.getElementById("p-" + id); if (!p || !c) return;
  const was = $(".card.open");
  closePack();
  if (was === c) { history.replaceState(null, "", location.pathname + location.search); return; }
  c.classList.add("open");
  let last = c;
  [...c.parentNode.querySelectorAll(".card:not([hidden])")].forEach((x) => { if (x.offsetTop === c.offsetTop) last = x; });
  const d = document.createElement("div"); d.className = "pd"; d.id = "pd";
  d.innerHTML = `<div class="pdi"><button class="x" data-shut aria-label="Close">×</button>
      <div class="pdc"><img src="${esc(p.cover)}" alt="${esc(p.name)} cover"></div>
      <div class="pdb">
        <div class="ph"><div><h3>${esc(p.name)}</h3><div class="pf">${esc(p.sub)} · ${esc(p.count)}</div></div><div class="price">${money(p.price)}</div></div>
        <span class="deal">3 for 2 · mix any packs</span>
        <p class="pi">${esc(p.blurb)}</p>
        <div class="pv">${sounds(p)}</div>
        <div class="buy"><button class="btn" data-free="${p.id}">Free samples</button><button class="btn acid" data-add="${p.id}">Add to cart</button></div>
      </div></div>
    <div class="sim"><h4>Similar packs</h4><div class="simg">${similar(p).map((q) => `<div class="mc"><img src="${esc(q.cover)}" alt="" data-open="${q.id}"><b data-open="${q.id}">${esc(q.name)}</b><div class="mp"><span>${money(q.price)}</span><button class="btn acid" data-add="${q.id}">Add to cart</button></div></div>`).join("")}</div></div>`;
  last.after(d); paintCart();
  history.replaceState(null, "", location.pathname + location.search + "#pack/" + id);
  if (scroll) requestAnimationFrame(() => d.scrollIntoView({ behavior: "smooth", block: "start" }));
}

document.addEventListener("click", (e) => {
  const t = e.target;
  if (t.closest(".pv button")) return;
  const ch = t.closest(".ch");
  if (ch) {
    closePack();
    document.querySelectorAll(".ch").forEach((c) => c.classList.toggle("on", c === ch));
    const f = ch.dataset.f;
    document.querySelectorAll(".world").forEach((w) => {
      const cards = [...w.querySelectorAll(".card")];
      cards.forEach((c) => c.hidden = f === "drums" ? c.dataset.type !== "drums" : false);
      w.hidden = f === "all" ? false : f === "drums" ? !cards.some((c) => !c.hidden) : w.dataset.world !== f;
    });
    return;
  }
  const add = t.closest("[data-add]"); if (add) { inCart(add.dataset.add) ? openCart() : addToCart(add.dataset.add); return; }
  const rm = t.closest("[data-rm]"); if (rm) { removeFromCart(rm.dataset.rm); return; }
  if (t.closest("#cartBtn")) { $("#cartDd").hidden ? openCart() : closeCart(); return; }
  if (t.closest("[data-shut]")) { const o = $(".card.open"); if (o) openPack(o.id.slice(2)); return; }
  const op = t.closest("[data-open]"); if (op) {
    closeCart();
    const id = op.dataset.open, c = document.getElementById("p-" + id);
    if (c && (c.hidden || c.closest(".world").hidden)) document.querySelector('.ch[data-f="all"]').click();
    openPack(id); return;
  }
  const fr = t.closest("[data-free]"); if (fr) { showFree(fr.dataset.free); return; }
  if (t.closest("#scrim") || t.closest("[data-close]")) { closeDrawer(); return; }
  if (!t.closest("#cartDd")) closeCart();
});
document.addEventListener("keydown", (e) => { if (e.key === "Escape") { closeDrawer(); closeCart(); } });

loadShop().then(() => {
  render(); paintCart();
  if (location.hash.startsWith("#pack/")) openPack(location.hash.slice(6));
  else if (location.hash === "#cart" && cart.length) openCart();
  else if (location.hash.length > 1) { const el = document.getElementById(location.hash.slice(1)); if (el) el.scrollIntoView(); }
});
